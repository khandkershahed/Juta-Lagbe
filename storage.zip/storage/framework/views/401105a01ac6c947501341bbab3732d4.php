<?php if(
    (is_countable($brands) && count($brands) > 0) ||
        (is_countable($categorys) && count($categorys) > 0) ||
        (is_countable($products) && count($products) > 0)): ?>
    <div class="ps-result__content">
        <div class="row m-0">
            <div class="col-12 col-lg-4 pl-0">
                <div class="search-ctg">
                    <div class="row">
                        <?php if(is_countable($brands) && count($brands) > 0): ?>
                            <div class="col-12">
                                <h4 class="fw-bold mb-4 site_text_color">Brands</h4>
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h4><a class="search_titles" href="#"><?php echo e($brand->name); ?></a></h4>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <?php if(is_countable($categorys) && count($categorys) > 0): ?>
                            <div class="col-12">
                                <h4 class="fw-bold mb-4 site_text_color">Categorys</h4>
                                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <h4>
                                        <a class="search_titles"
                                            href="<?php echo e(route('category.products', $category->slug)); ?>"><?php echo e($category->name); ?></a>
                                    </h4>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-12 col-lg-8 pr-0">
                <div class="searching-div">
                    <?php if(count($products) > 0): ?>
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="ps-product ps-product--horizontal top-search-product">
                                <div class="top-search-product-img">
                                    <a class="ps-product__image search-img"
                                        href="<?php echo e(route('product.details', $search_product->slug)); ?>">
                                        <figure>
                                            <img class="img-fluid searched-product"
                                                src="<?php echo e(asset('storage/' . $search_product->thumbnail)); ?>"
                                                alt="alt"
                                                onerror="this.onerror=null;this.src='<?php echo e(asset('images/no-preview.png')); ?>';" />
                                        </figure>
                                    </a>
                                </div>
                                <div class="ps-product__content pt-0">
                                    <h4 class="ps-product__title" style="height: auto; min-height:auto">
                                        <a href="<?php echo e(route('product.details', $search_product->slug)); ?>">
                                            <?php echo e($search_product->name); ?>

                                        </a>
                                    </h4>
                                    <p class="ps-product__desc text-dark" style="display: block">
                                        <?php echo implode(' ', array_slice(explode(' ', strip_tags($search_product->short_description)), 0, 10)); ?>...
                                    </p>
                                    
                                    <?php if(!empty($search_product->unit_discount_price)): ?>
                                        <div class="ps-product__meta mb-4">
                                            <span class="">৳<?php echo e($search_product->unit_discount_price); ?></span>
                                            <span class="ps-product__del">৳<?php echo e($search_product->unit_price); ?></span>
                                        </div>
                                    <?php else: ?>
                                        <div class="ps-product__meta mb-4">
                                            <span
                                                class="ps-product__price sale">৳<?php echo e($search_product->unit_price); ?></span>
                                        </div>
                                    <?php endif; ?>

                                    
                                    <div class="d-flex align-items-center">
                                        <a href="<?php echo e(route('buy.now', $search_product->id)); ?>"
                                            class="btn btn-primary mr-1 mr-lg-3">
                                            Buy Now
                                        </a>
                                        <a href="<?php echo e(route('cart.store', $search_product->id)); ?>"
                                            class="btn btn-outline-primary add_to_cart"
                                            data-product_id="<?php echo e($search_product->id); ?>" data-product_qty="1"
                                            onclick="addToCart(event, '<?php echo e(csrf_token()); ?>', '<?php echo e(route('cart.store', $search_product->id)); ?>')">
                                            Add To Cart
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="ps-result__viewall"><a href="<?php echo e(route('allproducts')); ?>">View all</a></div>
                    <?php else: ?>
                        <div class="row m-0 p-2 shadow-lg bg-white border rounded d-flex align-items-center">
                            <h4 class="text-danger text-center">No Product Found. Search again.</h4>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

    </div>
<?php else: ?>
    <div class="ps-result__content">
        <div class="row m-0">
            <div class="col-12 col-lg-5">
                <div class="text-center p-4">
                    <h4 style="color: #ae0a46;"> Nothing Found ! Search again.</h4>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/frontend/layouts/search.blade.php ENDPATH**/ ?>