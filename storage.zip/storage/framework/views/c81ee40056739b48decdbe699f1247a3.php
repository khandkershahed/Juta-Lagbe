<?php if (isset($component)) { $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $attributes; } ?>
<?php $component = App\View\Components\AdminAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminAppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Product Review Edit')]); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-header bg-dark align-items-center">
                        <h3 class="card-title text-white">Review List</h3>
                        <div>
                            <a type="button" href="<?php echo e(route('admin.product-review.index')); ?>"
                                class="btn btn-light-primary">
                                <i class="fa-solid fa-plus"></i> Back
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="post"
                            action="<?php echo e(route('admin.product-review.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-lg-7" mb-7>
                                    <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'product_id','class' => 'col-form-label required fw-bold fs-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'product_id','class' => 'col-form-label required fw-bold fs-6']); ?><?php echo e(__('Select Product')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                    <select class="form-select form-select-solid" data-control="select2"
                                        data-close-on-select="false" data-placeholder="Select an option"
                                        data-allow-clear="true" id="product_id" name="product_id"
                                        data-hide-search="false" data-placeholder="Select an option">
                                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($product->id); ?>" <?php if(old('product_id') == $product->id): echo 'selected'; endif; ?>><?php echo e($product->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-lg-5" mb-7>
                                    <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Name <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['type' => 'text','name' => 'name','id' => 'name','class' => 'form-control mb-2','placeholder' => 'Reviwer Name','value' => old('name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'name','id' => 'name','class' => 'form-control mb-2','placeholder' => 'Reviwer Name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-6" mb-7>
                                    <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Date <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['type' => 'date','name' => 'date','id' => 'date','class' => 'form-control mb-2','placeholder' => '11/25/2024','value' => old('date')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'date','name' => 'date','id' => 'date','class' => 'form-control mb-2','placeholder' => '11/25/2024','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('date'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-6" mb-7>
                                    <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Rating <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginalff6880852fb7a3f71461ce3b06af5a25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.select-option','data' => ['id' => 'kt_ecommerce_add_product_status_select','class' => 'form-select mb-2','dataControl' => 'select2','dataHideSearch' => 'true','name' => 'rating','dataPlaceholder' => 'Select an option']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'kt_ecommerce_add_product_status_select','class' => 'form-select mb-2','data-control' => 'select2','data-hide-search' => 'true','name' => 'rating','data-placeholder' => 'Select an option']); ?>
                                        <option>Choose Rating</option>
                                        <option value="1" <?php if(old('rating') == "1"): echo 'selected'; endif; ?>>1</option>
                                        <option value="2" <?php if(old('rating') == "2"): echo 'selected'; endif; ?>>2</option>
                                        <option value="3" <?php if(old('rating') == "3"): echo 'selected'; endif; ?>>3</option>
                                        <option value="4" <?php if(old('rating') == "4"): echo 'selected'; endif; ?>>4</option>
                                        <option value="5" <?php if(old('rating') == "5"): echo 'selected'; endif; ?>>5</option>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $attributes = $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $component = $__componentOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-6" mb-7>
                                    <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Image <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['type' => 'file','name' => 'image','id' => 'image','class' => 'form-control mb-2','placeholder' => 'choose image','value' => old('image')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'file','name' => 'image','id' => 'image','class' => 'form-control mb-2','placeholder' => 'choose image','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('image'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-6" mb-7>
                                    <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'status','class' => 'col-form-label required fw-bold fs-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'status','class' => 'col-form-label required fw-bold fs-6']); ?>
                                        <?php echo e(__('Select a Status ')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginalff6880852fb7a3f71461ce3b06af5a25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.select-option','data' => ['id' => 'status','name' => 'status','dataHideSearch' => 'true','dataPlaceholder' => 'Select an option']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'status','name' => 'status','data-hide-search' => 'true','data-placeholder' => 'Select an option']); ?>
                                        <option></option>
                                        <option value="active" <?php if(old('status')=="active"): echo 'selected'; endif; ?>>Active</option>
                                        <option value="inactive" <?php if(old('status')=="inactive"): echo 'selected'; endif; ?>>Inactive</option>
                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $attributes = $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $component = $__componentOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
                                </div>
                                <div class="col-lg-12 mb-7">
                                    <div class="mb-5 fv-row">
                                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Review <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                        <textarea name="meta_description" class="ckeditor"><?php echo old('meta_description'); ?></textarea>
                                        <div class="text-muted fs-7">
                                            Add Review.
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-7">
                                    <button type="submit" class="btn btn-primary">
                                        <span class="indicator-label"> Save Changes </span>
                                        </span>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $attributes = $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $component = $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/admin/pages/productReview/create.blade.php ENDPATH**/ ?>