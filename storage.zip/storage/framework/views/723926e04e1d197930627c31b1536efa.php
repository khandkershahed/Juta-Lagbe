<?php if (isset($component)) { $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $attributes; } ?>
<?php $component = App\View\Components\AdminAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminAppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Product Review List')]); ?>
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="card card-flush mt-10">
                    <div class="card-header bg-dark align-items-center">
                        <h3 class="card-title text-white">Review List</h3>
                        <div>
                            <a type="button" href="<?php echo e(route('admin.product-review.create')); ?>"
                                class="btn btn-light-primary">
                                <i class="fa-solid fa-plus"></i> Create
                            </a>
                        </div>
                    </div>

                    <div class="card-body table-responsive">
                        <table class="table my-datatable table-striped table-row-bordered gy-5 gs-7 border rounded">
                            <thead>
                                <tr class="text-center text-gray-400 fw-bolder fs-7 text-uppercase gs-0">
                                    <th width="5%"><?php echo e(__('Sl')); ?></th>
                                    <th width="10%"><?php echo e(__('Product Image')); ?></th>
                                    <th width="35%"><?php echo e(__('Product Name')); ?></th>
                                    <th width="20%"><?php echo e(__('Client Name')); ?></th>
                                    <th width="10%"><?php echo e(__('rating')); ?></th>
                                    <th width="10%"><?php echo e(__('status')); ?></th>
                                    <th width="10%" class="text-center"><?php echo e(__('Action')); ?></th>
                                </tr>
                            </thead>
                            <tbody class="text-center">
                                <?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td>
                                            <img class="w-50px h-50px"
                                                src="<?php echo e(asset('storage/' . optional($review->product)->thumbnail)); ?>"
                                                alt="<?php echo e(optional($review->product)->name); ?>"
                                                onerror="this.onerror=null; this.src='<?php echo e(asset('frontend/img/no-blogs.jpg')); ?>';">
                                        </td>
                                        <td><?php echo e(optional($review->product)->name); ?></td>
                                        <td class="text-center">
                                            <?php echo e($review->name); ?>

                                        </td>

                                        <td class="text-center"><?php echo e($review->rating); ?> <i class="fas fa-star text-warning"></i></td>
                                        <td>
                                            <span
                                                class="badge <?php echo e($review->status == 'active' ? 'bg-success' : 'bg-danger'); ?>">
                                                <?php echo e($review->status == 'active' ? 'Active' : 'InActive'); ?></span>
                                        </td>
                                        <td class="text-center">
                                            
                                            <a href="<?php echo e(route('admin.product-review.edit', $review->id)); ?>"
                                                class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                                <i class="fa-solid fa-pen"></i>
                                            </a>
                                            <a href="<?php echo e(route('admin.product-review.destroy', $review->id)); ?>"
                                                class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1 delete"
                                                data-kt-docs-table-filter="delete_row">
                                                <i class="fa-solid fa-trash-can-arrow-up"></i>
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $attributes = $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $component = $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/admin/pages/productReview/index.blade.php ENDPATH**/ ?>