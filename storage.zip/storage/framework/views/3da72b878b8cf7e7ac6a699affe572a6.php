<div class="ps-navigation--footer">
    <div>
        <a href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(!empty(optional($setting)->site_logo_white) ? asset('storage/' . optional($setting)->site_logo_white) : asset('frontend/img/logo.png')); ?>"
                style="width: 100%; padding: 20px; border-radius: 12px"
                onerror="this.onerror=null; this.src='/images/default_logo-2.png';">
        </a>
    </div>
    <div class="d-flex align-items-center">
        <div class="ps-nav__item"><a href="<?php echo e(route('login')); ?>">
                <img src="<?php echo e(asset('images/icon-profile.svg')); ?>" style="width: 20px" alt="">
            </a>
        </div>
        <div class="ps-nav__item">
            <a href="<?php echo e(route('user.wishlist')); ?>">
                
                <img src="<?php echo e(asset('images/icon-heart.svg')); ?>" style="width: 20px" alt="">
                <?php
                    $wishlistCount = 0; // Default value in case user is not authenticated
                    if (Auth::check()) {
                        $userId = Auth::id();
                        $wishlistCount = App\Models\Wishlist::where('user_id', $userId)->count();
                    }
                ?>
                <span class="badge wishlistCount"><?php echo e($wishlistCount); ?></span>
            </a>
        </div>
        <div class="ps-nav__item">
            <a href="<?php echo e(route('cart')); ?>">
                <img src="<?php echo e(asset('images/icon-cart.svg')); ?>" style="width: 20px" alt="">
                <span class="badge cartCount"><?php echo e(Cart::instance('cart')->count()); ?></span>
            </a>
        </div>
        <div class="ps-nav__item">
            <a href="#" id="open-menu">
                
                <i class="fa-solid fa-bars pt-2 text-white"></i>
            </a>
            <a href="#" id="close-menu">
                <i class="fa-solid fa-xmark text-white"></i>
            </a>
        </div>
    </div>
</div>
<div class="ps-menu--slidebar">
    <div class="ps-menu__content">
        <ul class="menu--mobile">

            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="has-mega-menu">
                    <a href="<?php echo e(route('category.products', $category->slug)); ?>">
                        <?php echo e($category->name); ?>

                    </a>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <li class="has-mega-menu">
                <a href="<?php echo e(route('allproducts')); ?>">
                    Shop
                </a>
            </li>
            <?php if(!empty(optional($special_offer)->slug)): ?>
                <li>
                    <a href="<?php echo e(route('special.products', optional($special_offer)->slug)); ?>" class="button-new mt-2">
                        <span class="fold"></span>

                        <div class="points_wrapper">
                            <i class="point"></i>
                            <i class="point"></i>
                            <i class="point"></i>
                            <i class="point"></i>
                            <i class="point"></i>
                            <i class="point"></i>
                            <i class="point"></i>
                            <i class="point"></i>
                            <i class="point"></i>
                            <i class="point"></i>
                        </div>

                        <span class="inner"><svg class="icon" fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                xmlns="http://www.w3.org/2000/svg" stroke-linecap="round" stroke-linejoin="round"
                                stroke-width="2.5">
                                <polyline
                                    points="13.18 1.37 13.18 9.64 21.45 9.64 10.82 22.63 10.82 14.36 2.55 14.36 13.18 1.37">
                                </polyline>
                            </svg><?php echo e(optional($special_offer)->button_name); ?></span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </div>
    <div class="ps-menu__footer">
        <div class="ps-menu__item">
            <div class="col-12 col-md-7">
                <div class="ps-footer--contact mobile-help">
                    <h5 class="ps-footer__title">Need help</h5>
                    <div class="ps-footer__fax number-mobile">
                        <div class="d-flex align-items-center">
                            <img class="" src="<?php echo e(asset('images/whatsapp-icons.gif')); ?>" alt=""
                                width="55px">
                            <?php echo e(optional($setting)->primary_phone); ?>

                        </div>

                    </div>
                    <p class="ps-footer__work">
                        Monday – Friday: 9:00-20:00<br>Saturday: 11:00 – 15:00 <br>
                        <a
                            href="mailto:<?php echo e(optional($setting)->contact_email); ?>"><?php echo e(optional($setting)->contact_email); ?></a>
                    </p>
                </div>
            </div>
            <div class="col-12 col-md-7">
                <div class="row">
                    <div class="col-6 col-md-4">
                        <div class="ps-footer--block">
                            <h5 class="ps-block__title">Account</h5>
                            <ul class="ps-block__list">
                                <li><a href="<?php echo e(route('user.account.details')); ?>">My Account</a></li>
                                <li><a href="<?php echo e(route('user.order.history')); ?>">My Orders</a></li>
                                <li><a href="<?php echo e(route('user.quick.order')); ?>">Quick Order</a></li>
                                <li><a href="<?php echo e(route('user.wishlist')); ?>">Shopping List</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-6 col-md-4">
                        <div class="ps-footer--block">
                            <h5 class="ps-block__title">Policy</h5>
                            <ul class="ps-block__list">
                                <li><a href="<?php echo e(asset('return-policy')); ?>">Returns</a></li>
                                <li><a href="<?php echo e(asset('privacy/policy')); ?>">Privacy & Policy</a></li>
                                <li><a href="<?php echo e(asset('terms-condition')); ?>">Terms & Conditions</a></li>
                                <li><a href="<?php echo e(asset('faq')); ?>">Faq</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-12 col-md-4">
                        <div class="ps-footer--block">
                            <h5 class="ps-block__title text-center mb-0">Visitor Count</h5>
                            <div class="visitor-box">
                                <div class="main-counter">
                                    <h1 class="mb-0"><?php echo e($getOnlineVisitorCount + 10); ?></h1>
                                    <div class="sub-counter">
                                        <p>ONLINE NOW</p>
                                    </div>
                                </div>
                                <div class="d-flex justify-content-between align-items-center">
                                    
                                    <div class="total-count">
                                        <small class="mb-0 text-white">Total</small>
                                        <small class="mb-0 text-white fw-bold"><?php echo e(getTotalVisitorCount() + 1000); ?></small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<button class="btn scroll-top"><i class="fa fa-angle-double-up"></i></button>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/frontend/layouts/extra.blade.php ENDPATH**/ ?>