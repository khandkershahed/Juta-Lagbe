<?php if (isset($component)) { $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $attributes; } ?>
<?php $component = App\View\Components\AdminAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminAppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        td {
            vertical-align: middle;
        }
    </style>
    <div class="post d-flex flex-column-fluid" id="kt_post">
        <div class="container-xxl">
            <div class="card card-flush">
                <form id="bulk-delete-form" action="<?php echo e(route('admin.categories.bulk-delete')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="card-header align-items-center py-5 gap-2 gap-md-5 bg-dark rounded-2">
                        <div class="card-title">
                            <div class="d-flex align-items-center position-relative my-1">
                                <button type="submit" id="bulkDelete" class="btn btn-danger"
                                    style="display:none;">Delete
                                    Selected</button>
                            </div>
                            <span class="ms-4 text-white">Manage Your Categories</span>
                        </div>
                        <div class="card-toolbar flex-row-fluid justify-content-end gap-5">
                            <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-white"><i
                                    class="fa-solid fa-plus"></i> Add Category</a>
                        </div>
                    </div>
                    <div class="card-body pt-0">
                        <div class="table-responsive">
                            <table class="table my-datatable table-striped table-row-bordered gy-5 gx-5 border rounded">
                                <thead>
                                    <tr class="fw-bold fs-6 text-gray-800 px-7">
                                        <th width="10%">
                                            <div class="form-check form-check-sm form-check-solid">
                                                <input class="form-check-input metronic_select_all" type="checkbox"
                                                    id="select-all" />
                                            </div>
                                        </th>
                                        <th width="10%"><?php echo e(__('category.Sl')); ?></th>
                                        <th width="10%"><?php echo e(__('category.Parent')); ?></th>
                                        <th width="25%"><?php echo e(__('category.logo')); ?></th>
                                        <th width="15%"><?php echo e(__('category.Name')); ?></th>
                                        <th width="10%"><?php echo e(__('category.Status')); ?></th>
                                        <th width="20%" class="text-end pe-5"><?php echo e(__('category.Action')); ?></th>
                                    </tr>
                                </thead>
                                <tbody class="fw-bold text-gray-600">
                                    <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <tr>
                                            <td>
                                                <div class="form-check form-check-sm form-check-solid">
                                                    <input class="form-check-input bulkDelete-checkbox" type="checkbox"
                                                        name="categories[]" value="<?php echo e($category->id); ?>" />
                                                </div>
                                            </td>
                                            <td><img class="w-65px" src="<?php echo e(asset('storage/' . $category->logo)); ?>"
                                                alt="<?php echo e($category->name); ?>"></td>
                                            <td><?php echo e($loop->iteration); ?></td>
                                            <td>
                                                <?php echo e($category->parent_id ? $category->parent->name : 'N/A'); ?>

                                            </td>
                                            <td>
                                                <?php echo e($category->name); ?>

                                            </td>
                                            <td>
                                                <div
                                                    class="badge <?php echo e($category->status == 'active' ? 'badge-light-success' : 'badge-light-danger'); ?>">
                                                    <?php echo e($category->status == 'active' ? 'Active' : 'InActive'); ?>

                                                </div>
                                            </td>
                                            <td class="text-end">
                                                <a href="<?php echo e(route('admin.categories.show', $category->id)); ?>"
                                                    class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                                    <i class="fa-solid fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('admin.categories.edit', $category->id)); ?>"
                                                    class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                                    <i class="fa-solid fa-pen"></i>
                                                </a>
                                                <a href="<?php echo e(route('admin.categories.destroy', $category->id)); ?>"
                                                    class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1 delete"
                                                    data-kt-docs-table-filter="delete_row">
                                                    <i class="fa-solid fa-trash-can-arrow-up"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td>
                                                    <div
                                                        class="form-check form-check-sm form-check-custom form-check-solid">
                                                        <input class="form-check-input bulkDelete-checkbox"
                                                            type="checkbox" name="categories[]"
                                                            value="<?php echo e($child->id); ?>" />
                                                    </div>
                                                </td>

                                                <td>
                                                    <?php echo e($loop->parent->iteration); ?>.<?php echo e($loop->iteration); ?>

                                                </td>
                                                <td>
                                                    <?php echo e($child->parent->name ?? 'N/A'); ?>

                                                </td>
                                                <td>
                                                    -- <?php echo e($child->name); ?>

                                                </td>
                                                <td>
                                                    <div
                                                        class="badge <?php echo e($child->status == 'active' ? 'badge-light-success' : 'badge-light-danger'); ?>">
                                                        <?php echo e($child->status == 'active' ? 'Active' : 'InActive'); ?>

                                                    </div>
                                                </td>
                                                <td class="text-center">
                                                    <a href="<?php echo e(route('admin.categories.show', $child->id)); ?>"
                                                        class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                                        <i class="fa-solid fa-eye"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('admin.categories.edit', $child->id)); ?>"
                                                        class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                                        <i class="fa-solid fa-pen"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('admin.categories.destroy', $child->id)); ?>"
                                                        class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1 delete"
                                                        data-kt-docs-table-filter="delete_row">
                                                        <i class="fa-solid fa-trash-can-arrow-up"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).on('change', '.status-toggle', function() {
                const id = $(this).data('id');
                const route = "<?php echo e(route('admin.categories.toggle-status', ':id')); ?>".replace(':id', id);
                toggleStatus(route, id);
            });

            function toggleStatus(route, id) {
                $.ajax({
                    url: route,
                    type: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            alert('Status updated successfully!');
                            table.ajax.reload(null, false); // Reload the DataTable
                        } else {
                            alert('Failed to update status.');
                        }
                    },
                    error: function() {
                        alert('An error occurred while updating the status.');
                    }
                });
            }
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $attributes = $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $component = $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/admin/pages/categories/index.blade.php ENDPATH**/ ?>