<?php if (isset($component)) { $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $attributes; } ?>
<?php $component = App\View\Components\AdminAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminAppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Website Setting')]); ?>
    <div class="row g-2" id="columns-container">
        <div class="row py-10 pt-0">
            <div class="col-lg-2">
                <div class="custom-fixed-top">
                    <div class="d-flex flex-column flex-md-row rounded border bg-white">
                        <?php echo $__env->make('admin.pages.setting.partials.tab_trigger', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                </div>
            </div>
            <div class="card col-lg-10">
                <form class="form" action="<?php echo e(route('admin.settings.updateOrCreate')); ?>" method="POST"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div class="card-body">
                        <div class="tab-content bg-white p-5" id="myTabContent">
                            <div class="tab-pane fade active show" id="generalInfo" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 general_info_container">
                                        <?php echo $__env->make('admin.pages.setting.partials.general_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="footer" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 footer_container">
                                        <?php echo $__env->make('admin.pages.setting.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="businessHours" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 business_hours_container">
                                        <?php echo $__env->make('admin.pages.setting.partials.business_hours', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            

                            <div class="tab-pane fade" id="services" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 service_container">
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="products" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 product_container">
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="galleries" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 gallery_container">
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="banner" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 banner_container">
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonials" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 testimonial_container">
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="seo" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 seo_container">
                                        <?php echo $__env->make('admin.pages.setting.partials.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="socialLinks" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 social_links_container">
                                        <?php echo $__env->make('admin.pages.setting.partials.social_links', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="privacy" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 privacy_container">
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="terms" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 terms_container">
                                        
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="fonts" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 fonts_container">
                                        
                                    </div>
                                </div>
                            </div>
                            
                            <div class="tab-pane fade" id="advance" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 advance_container">
                                        <?php echo $__env->make('admin.pages.setting.partials.advance', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="setting" role="tabpanel">
                                <div class="row">
                                    <div class="col-lg-12 setting_container">
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer py-3">
                        <div class="text-end">
                            <?php if (isset($component)) { $__componentOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.button','data' => ['type' => 'submit','class' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'primary']); ?>
                                <?php echo e(__('Submit')); ?>

                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9)): ?>
<?php $attributes = $__attributesOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9; ?>
<?php unset($__attributesOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9)): ?>
<?php $component = $__componentOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9; ?>
<?php unset($__componentOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9); ?>
<?php endif; ?>
                        </div>
                    </div>
                </form>
            </div>
        </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $attributes = $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $component = $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/admin/pages/setting/index.blade.php ENDPATH**/ ?>