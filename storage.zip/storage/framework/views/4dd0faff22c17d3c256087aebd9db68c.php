<?php if (isset($component)) { $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $attributes; } ?>
<?php $component = App\View\Components\AdminAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminAppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Page Banner Edit')]); ?>
    <div class="card card-flash">
        <div class="card-header mt-6">
            <div class="card-title"></div>
            <div class="card-toolbar">
                <a href="<?php echo e(route('admin.banner.index')); ?>" class="btn btn-light-info rounded-2">
                    <span class="svg-icon svg-icon-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                            fill="none">
                            <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5"
                                fill="currentColor" />
                            <rect x="10.8891" y="17.8033" width="12" height="2" rx="1"
                                transform="rotate(-90 10.8891 17.8033)" fill="currentColor" />
                            <rect x="6.01041" y="10.9247" width="12" height="2" rx="1"
                                fill="currentColor" />
                        </svg>
                    </span>
                    Back to the list
                </a>
            </div>
        </div>
        <div class="card-body pt-0">

            <form class="form" action="<?php echo e(route('admin.banner.update',$banner->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row">
                    <div class="col-lg-4 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'name','class' => 'col-form-label fw-bold fs-6 required']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'name','class' => 'col-form-label fw-bold fs-6 required']); ?><?php echo e(__('Page Name')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalff6880852fb7a3f71461ce3b06af5a25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.select-option','data' => ['id' => 'page_name','name' => 'page_name','dataHideSearch' => 'true','dataPlaceholder' => 'Select an option']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'page_name','name' => 'page_name','data-hide-search' => 'true','data-placeholder' => 'Select an option']); ?>
                            <option></option>
                            <option value="home_slider" <?php if($banner->page_name == 'home_slider'): echo 'selected'; endif; ?>>Home Page Slider</option>
                            <option value="home_slider_bottom_first" <?php if($banner->page_name == 'home_slider_bottom_first'): echo 'selected'; endif; ?>>Home Page Slider Bottom First</option>
                            <option value="home_slider_bottom_second" <?php if($banner->page_name == 'home_slider_bottom_second'): echo 'selected'; endif; ?>>Home Page Slider Bottom Second</option>
                            <option value="home_slider_bottom_third" <?php if($banner->page_name == 'home_slider_bottom_third'): echo 'selected'; endif; ?>>Home Page Slider Bottom Third</option>
                            <option value="user" <?php if($banner->page_name == 'user'): echo 'selected'; endif; ?>>User Panel</option>
                            <option value="cart" <?php if($banner->page_name == 'cart'): echo 'selected'; endif; ?>>Cart Page</option>
                            <option value="checkout" <?php if($banner->page_name == 'checkout'): echo 'selected'; endif; ?>>Checkout Page</option>
                            <option value="faq" <?php if($banner->page_name == 'faq'): echo 'selected'; endif; ?>>FAQ</option>
                            <option value="terms" <?php if($banner->page_name == 'terms'): echo 'selected'; endif; ?>>Terms & Condition</option>
                            <option value="privacy" <?php if($banner->page_name == 'privacy'): echo 'selected'; endif; ?>>Privacy Policy</option>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $attributes = $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $component = $__componentOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
                    </div>
                    
                    <div class="col-lg-4">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'bg_image','class' => 'col-form-label fw-bold fs-6 required']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'bg_image','class' => 'col-form-label fw-bold fs-6 required']); ?><?php echo e(__('Background Image')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal3e938978070c04547663785a40685fbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e938978070c04547663785a40685fbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.file-input','data' => ['id' => 'bg_image','type' => 'file','name' => 'bg_image','source' => asset('storage/'.$banner->bg_image)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.file-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'bg_image','type' => 'file','name' => 'bg_image','source' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset('storage/'.$banner->bg_image))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e938978070c04547663785a40685fbe)): ?>
<?php $attributes = $__attributesOriginal3e938978070c04547663785a40685fbe; ?>
<?php unset($__attributesOriginal3e938978070c04547663785a40685fbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e938978070c04547663785a40685fbe)): ?>
<?php $component = $__componentOriginal3e938978070c04547663785a40685fbe; ?>
<?php unset($__componentOriginal3e938978070c04547663785a40685fbe); ?>
<?php endif; ?>
                    </div>
                    <div class="col-lg-4 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'title','class' => 'col-form-label fw-bold fs-6 ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'title','class' => 'col-form-label fw-bold fs-6 ']); ?><?php echo e(__('Title')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['id' => 'title','type' => 'text','name' => 'title','placeholder' => 'Enter the Title','value' => old('title',$banner->title)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'title','type' => 'text','name' => 'title','placeholder' => 'Enter the Title','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('title',$banner->title))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                    </div>
                    <div class="col-lg-4 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'subtitle','class' => 'col-form-label fw-bold fs-6 ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'subtitle','class' => 'col-form-label fw-bold fs-6 ']); ?><?php echo e(__('Subtitle')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['id' => 'subtitle','type' => 'text','name' => 'subtitle','placeholder' => 'Enter the Subtitle','value' => old('subtitle',$banner->subtitle)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'subtitle','type' => 'text','name' => 'subtitle','placeholder' => 'Enter the Subtitle','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('subtitle',$banner->subtitle))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                    </div>
                    <div class="col-lg-4 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'banner_link','class' => 'col-form-label fw-bold fs-6 ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'banner_link','class' => 'col-form-label fw-bold fs-6 ']); ?><?php echo e(__('Banner Link')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['id' => 'banner_link','type' => 'text','name' => 'banner_link','placeholder' => 'Enter the Banner_Link','value' => old('banner_link',$banner->banner_link)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'banner_link','type' => 'text','name' => 'banner_link','placeholder' => 'Enter the Banner_Link','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('banner_link',$banner->banner_link))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                    </div>
                    <div class="col-lg-4 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'badge','class' => 'col-form-label fw-bold fs-6 ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'badge','class' => 'col-form-label fw-bold fs-6 ']); ?><?php echo e(__('Badge')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['id' => 'badge','type' => 'text','name' => 'badge','placeholder' => 'Enter the Badge','value' => old('badge',$banner->badge)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'badge','type' => 'text','name' => 'badge','placeholder' => 'Enter the Badge','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('badge',$banner->badge))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                    </div>
                    <div class="col-lg-4 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'button_name','class' => 'col-form-label fw-bold fs-6 ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'button_name','class' => 'col-form-label fw-bold fs-6 ']); ?><?php echo e(__('Button Name')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['id' => 'button_name','type' => 'text','name' => 'button_name','placeholder' => 'Enter the Button Name','value' => old('button_name',$banner->button_name)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'button_name','type' => 'text','name' => 'button_name','placeholder' => 'Enter the Button Name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('button_name',$banner->button_name))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                    </div>
                    <div class="col-lg-4 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'button_link','class' => 'col-form-label fw-bold fs-6 ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'button_link','class' => 'col-form-label fw-bold fs-6 ']); ?><?php echo e(__('Button Link')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['id' => 'button_link','type' => 'url','name' => 'button_link','placeholder' => 'Enter the Button Link','value' => old('button_link',$banner->button_link)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'button_link','type' => 'url','name' => 'button_link','placeholder' => 'Enter the Button Link','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('button_link',$banner->button_link))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                    </div>
                    <div class="col-lg-4 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'status','class' => 'col-form-label required fw-bold fs-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'status','class' => 'col-form-label required fw-bold fs-6']); ?>
                            <?php echo e(__('Select a Status ')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalff6880852fb7a3f71461ce3b06af5a25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.select-option','data' => ['id' => 'status','name' => 'status','dataHideSearch' => 'true','dataPlaceholder' => 'Select an option']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'status','name' => 'status','data-hide-search' => 'true','data-placeholder' => 'Select an option']); ?>
                            <option></option>
                            <option value="active" <?php if($banner->status == "active"): echo 'selected'; endif; ?> >Active</option>
                            <option value="inactive" <?php if($banner->status == "inactive"): echo 'selected'; endif; ?> >Inactive</option>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $attributes = $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $component = $__componentOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
                    </div>


                </div>
                <div class="text-center pt-15">
                    <?php if (isset($component)) { $__componentOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.button','data' => ['type' => 'submit','class' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'primary']); ?>
                        <?php echo e(__('Submit')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9)): ?>
<?php $attributes = $__attributesOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9; ?>
<?php unset($__attributesOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9)): ?>
<?php $component = $__componentOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9; ?>
<?php unset($__componentOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9); ?>
<?php endif; ?>
                </div>

            </form>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $attributes = $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $component = $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/admin/pages/pageBanner/edit.blade.php ENDPATH**/ ?>