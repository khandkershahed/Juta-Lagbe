<div class="footer py-4 d-flex flex-lg-column" id="kt_footer">
     <div class="container-fluid d-flex flex-column flex-md-row align-items-center justify-content-between">
         <div class="text-dark order-2 order-md-1">
             <a href="http://<?php echo e(optional($setting)->copyright_url); ?>" target="_blank" class="text-gray-800 text-hover-primary">© <?php echo e(optional($setting)->copyright_title ?? optional($setting)->site_title); ?></a>
         </div>

     </div>
 </div>

<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>