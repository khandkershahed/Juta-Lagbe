<label class="<?php echo e($class ?? 'col-lg-4 col-form-label required fw-bold fs-6'); ?>"
    for="<?php echo e($for ?? ''); ?>"><?php echo e($slot); ?>

</label>



<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/components/metronic/label.blade.php ENDPATH**/ ?>