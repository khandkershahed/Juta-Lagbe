<?php if (isset($component)) { $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $attributes; } ?>
<?php $component = App\View\Components\AdminAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminAppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Page Banner List')]); ?>
    <div class="card">
        <div class="card-header bg-dark align-items-center d-flex justify-content-between">
            <div>
                <h1 class="mb-0 text-center w-100 text-white">Manage Your Page Banner</h1>
            </div>
            <div>
                <a href="<?php echo e(route('admin.banner.create')); ?>" class="btn btn-white rounded-2">
                    <span class="svg-icon svg-icon-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                            fill="none">
                            <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5"
                                fill="currentColor" />
                            <rect x="10.8891" y="17.8033" width="12" height="2" rx="1"
                                transform="rotate(-90 10.8891 17.8033)" fill="currentColor" />
                            <rect x="6.01041" y="10.9247" width="12" height="2" rx="1"
                                fill="currentColor" />
                        </svg>
                    </span>
                    Add Banner
                </a>
            </div>
        </div>
        <div class="card-body py-0">
            <table class="table my-datatable table-striped table-row-bordered gy-5 gs-7">
                <thead class="bg-light-danger">
                    <tr class=" text-white fw-bolder fs-7 text-uppercase gs-0">
                        <th width="5%">Sl</th>
                        <th width="15%" class="text-center">Thumbnail Image</th>
                        <th width="15%" class="text-center">Background Image</th>
                        <th width="20%">Page Name</th>
                        <th width="15%">Creacted At</th>
                        <th width="10%">Status</th>
                        <th width="20%" class="text-end">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($banners): ?>
                        <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="odd">
                                <td>
                                    <?php echo e($loop->iteration); ?>

                                </td>
                                <td class="text-center">
                                    <img class="w-50px h-50px"
                                        src="<?php echo e(!empty(optional($banner)->image) ? asset('storage/' . optional($banner)->image) : asset('images/no_image.jpg')); ?>"
                                        alt="<?php echo e($banner->page_name); ?>">
                                </td>
                                <td class="text-center">
                                    <img class="w-50px h-50px"
                                        src="<?php echo e(!empty(optional($banner)->bg_image) ? asset('storage/' . optional($banner)->bg_image) : asset('images/no_image.jpg')); ?>"
                                        alt="<?php echo e($banner->page_name); ?>">
                                </td>
                                <td class="text-info">
                                    <?php echo e(ucwords(str_replace(['_', '-', ',', '.', ';'], ' ', $banner->page_name))); ?>

                                </td>
                                <td>
                                    <?php echo e($banner->created_at->format('d F Y')); ?>

                                </td>
                                <td>
                                    <span class="badge <?php echo e($banner->status == 'active' ? 'bg-success' : 'bg-danger'); ?>">
                                        <?php echo e($banner->status == 'active' ? 'Active' : 'InActive'); ?></span>
                                </td>
                                <td class="text-end">
                                    <a href="#"
                                        class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1"
                                        data-bs-toggle="modal" data-bs-target="#faqViewModal_<?php echo e($banner->id); ?>">
                                        <i class="fa-solid fa-expand"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.banner.edit', $banner->id)); ?>"
                                        class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1">
                                        <i class="fa-solid fa-pen"></i>
                                    </a>
                                    <a href="<?php echo e(route('admin.banner.destroy', $banner->id)); ?>"
                                        class="btn btn-icon btn-bg-light btn-active-color-primary btn-sm me-1 delete"
                                        data-kt-docs-table-filter="delete_row">
                                        <i class="fa-solid fa-trash-can-arrow-up"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {


                $(document).on('change', '.status-toggle', function() {
                    const id = $(this).data('id');
                    const route = "<?php echo e(route('admin.banner.toggle-status', ':id')); ?>".replace(':id', id);
                    toggleStatus(route, id);
                });
            });
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $attributes = $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $component = $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/admin/pages/pageBanner/index.blade.php ENDPATH**/ ?>