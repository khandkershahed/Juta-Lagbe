        <input id="<?php echo e($id ?? ''); ?>" type="<?php echo e($type ?? 'text'); ?>"
            class="form-control form-control-solid <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="<?php echo e($name); ?>" step="0.01" maxlength="250"
            placeholder="<?php echo e($placeholder ?? ''); ?>" value="<?php echo e(old($name, $value ?? '')); ?>" <?php echo e($required ?? ''); ?>/>
        <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback">
                <?php echo e($message); ?>

            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/components/metronic/input.blade.php ENDPATH**/ ?>