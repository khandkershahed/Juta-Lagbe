<?php $__currentLoopData = $latest_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="popupQuickview<?php echo e($latest_product->id); ?>" data-backdrop="static" data-keyboard="false"
        tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-centered ps-quickview">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="wrap-modal-slider container-fluid ps-quickview__body">
                        <button class="close ps-quickview__close" type="button" data-dismiss="modal"
                            aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <div class="ps-product--detail">
                            <div class="row">
                                <div class="col-12 col-xl-6 pl-0">
                                    <div class="ps-product--gallery">
                                        <div class="ps-product__thumbnail p-0">
                                            <?php if($latest_product->multiImages->isNotEmpty()): ?>
                                                <?php $__currentLoopData = $latest_product->multiImages->slice(0, 5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $imagePath = 'storage/' . $image->photo;
                                                        $imageSrc = file_exists(public_path($imagePath))
                                                            ? asset($imagePath)
                                                            : asset('frontend/img/no-product.jpg');
                                                    ?>
                                                    <div class="slide">
                                                        <img src="<?php echo e($imageSrc); ?>"
                                                            alt="<?php echo e($latest_product->name); ?>" />
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <?php
                                                    $thumbnailPath = 'storage/' . $latest_product->thumbnail;
                                                    $thumbnailSrc = file_exists(public_path($thumbnailPath))
                                                        ? asset($thumbnailPath)
                                                        : asset('frontend/img/no-product.jpg');
                                                ?>
                                                <div class="slide">
                                                    <img src="<?php echo e($thumbnailSrc); ?>" alt="<?php echo e($latest_product->name); ?>" />
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="ps-gallery--image">
                                            <?php if($latest_product->multiImages->isNotEmpty()): ?>
                                                <?php $__currentLoopData = $latest_product->multiImages->slice(0, 5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $imagePath = 'storage/' . $image->photo;
                                                        $imageSrc = file_exists(public_path($imagePath))
                                                            ? asset($imagePath)
                                                            : asset('frontend/img/no-product.jpg');
                                                    ?>
                                                    <div class="slide">
                                                        <div class="ps-gallery__item">
                                                            <img src="<?php echo e($imageSrc); ?>"
                                                                alt="<?php echo e($latest_product->name); ?>" />
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <?php
                                                    $thumbnailPath = 'storage/' . $latest_product->thumbnail;
                                                    $thumbnailSrc = file_exists(public_path($thumbnailPath))
                                                        ? asset($thumbnailPath)
                                                        : asset('frontend/img/no-product.jpg');
                                                ?>
                                                <div class="slide">
                                                    <div class="ps-gallery__item">
                                                        <img src="<?php echo e($thumbnailSrc); ?>"
                                                            alt="<?php echo e($latest_product->name); ?>" />
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="pt-3">
                                            <span class="ps-list__title">SKU-Code: </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-xl-6 pr-0">
                                    <div class="ps-product__info mb-0">
                                        <div class="">
                                            <span
                                                class="ps-badge ps-badge--instock ps-badge-2"><?php echo e($latest_product->box_stock > 0 ? 'IN STOCK' : 'OUT OF STOCK'); ?></span>
                                        </div>
                                        <div class="ps-product__branch pt-2">
                                            <a href="#"
                                                style="text-transform: uppercase;"><?php echo e(optional($latest_product->brand)->name); ?></a>
                                        </div>
                                        <h4 class="">
                                            <a href="<?php echo e(route('product.details', $latest_product->slug)); ?>">
                                                <?php echo e($latest_product->name); ?>

                                            </a>
                                        </h4>
                                        <div class="ps-product__desc">
                                            <p><?php echo $latest_product->short_description; ?></p>
                                        </div>
                                        

                                        

                                        

                                        <div class="ps-product__feature">
                                            <?php if(!empty($latest_product->unit_discount_price)): ?>
                                                <div class="ps-product__meta">
                                                    <span
                                                        class="ps-product__price sale">৳<?php echo e($latest_product->unit_discount_price); ?></span>
                                                    <span
                                                        class="ps-product__del">৳<?php echo e($latest_product->unit_price); ?></span>
                                                </div>
                                            <?php else: ?>
                                                <div class="ps-product__meta">
                                                    <span
                                                        class="ps-product__price sale">৳<?php echo e($latest_product->unit_price); ?></span>
                                                </div>
                                            <?php endif; ?>

                                            <div class="ps-product__quantity">
                                                <h6>Quantity</h6>
                                                <div class="def-number-input number-input safari_only">
                                                    <button class="minus"
                                                        onclick="this.parentNode.querySelector('input[type=number]').stepDown()"><i
                                                            class="icon-minus"></i></button>
                                                    <input class="quantity" min="1" name="quantity"
                                                        value="1" type="number"
                                                        data-product_id="<?php echo e($latest_product->id); ?>" />
                                                    <button class="plus"
                                                        onclick="this.parentNode.querySelector('input[type=number]').stepUp()"><i
                                                            class="icon-plus"></i></button>
                                                </div>
                                            </div>
                                            <div class="d-flex align-items-center card-cart-btn">
                                                <a href="<?php echo e(route('buy.now', $latest_product->id)); ?>"
                                                    class="btn btn-primary mr-1 mr-lg-3 ">
                                                    Buy Now
                                                </a>
                                                <a href="<?php echo e(route('cart.store', $latest_product->id)); ?>"
                                                    class="btn btn-outline-primary add_to_cart buy-now-btn"
                                                    data-product_id="<?php echo e($latest_product->id); ?>" data-product_qty="1">
                                                    Add To Cart
                                                </a>
                                            </div>
                                        </div>

                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__currentLoopData = $deal_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="popupQuickview<?php echo e($deal_product->id); ?>" data-backdrop="static" data-keyboard="false"
        tabindex="-1" aria-hidden="true">
        <div class="modal-dialog modal-xl modal-dialog-centered ps-quickview">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="wrap-modal-slider container-fluid ps-quickview__body">
                        <button class="close ps-quickview__close" type="button" data-dismiss="modal"
                            aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <div class="ps-product--detail">
                            <div class="row">
                                <div class="col-12 col-xl-6 pl-0">
                                    <div class="ps-product--gallery">
                                        <div class="ps-product__thumbnail p-0">
                                            <?php if($deal_product->multiImages->isNotEmpty()): ?>
                                                <?php $__currentLoopData = $deal_product->multiImages->slice(0, 5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $imagePath = 'storage/' . $image->photo;
                                                        $imageSrc = file_exists(public_path($imagePath))
                                                            ? asset($imagePath)
                                                            : asset('frontend/img/no-product.jpg');
                                                    ?>
                                                    <div class="slide">
                                                        <img src="<?php echo e($imageSrc); ?>"
                                                            alt="<?php echo e($deal_product->name); ?>" />
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <?php
                                                    $thumbnailPath = 'storage/' . $deal_product->thumbnail;
                                                    $thumbnailSrc = file_exists(public_path($thumbnailPath))
                                                        ? asset($thumbnailPath)
                                                        : asset('frontend/img/no-product.jpg');
                                                ?>
                                                <div class="slide">
                                                    <img src="<?php echo e($thumbnailSrc); ?>" alt="<?php echo e($deal_product->name); ?>" />
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="ps-gallery--image">
                                            <?php if($deal_product->multiImages->isNotEmpty()): ?>
                                                <?php $__currentLoopData = $deal_product->multiImages->slice(0, 5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $imagePath = 'storage/' . $image->photo;
                                                        $imageSrc = file_exists(public_path($imagePath))
                                                            ? asset($imagePath)
                                                            : asset('frontend/img/no-product.jpg');
                                                    ?>
                                                    <div class="slide">
                                                        <div class="ps-gallery__item">
                                                            <img src="<?php echo e($imageSrc); ?>"
                                                                alt="<?php echo e($deal_product->name); ?>" />
                                                        </div>
                                                    </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <?php
                                                    $thumbnailPath = 'storage/' . $deal_product->thumbnail;
                                                    $thumbnailSrc = file_exists(public_path($thumbnailPath))
                                                        ? asset($thumbnailPath)
                                                        : asset('frontend/img/no-product.jpg');
                                                ?>
                                                <div class="slide">
                                                    <div class="ps-gallery__item">
                                                        <img src="<?php echo e($thumbnailSrc); ?>"
                                                            alt="<?php echo e($deal_product->name); ?>" />
                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-xl-6 pr-0">
                                    <div class="ps-product__info mb-0">
                                        <div class="ps-product__badges">
                                            <span
                                                class="ps-badge ps-badge--instock ps-badge-2"><?php echo e($deal_product->box_stock > 0 ? 'IN STOCK' : 'OUT OF STOCK'); ?></span>
                                        </div>
                                        <div class="ps-product__branch pt-2">
                                            <a href="#"><?php echo e(optional($deal_product->brand)->name); ?></a>
                                        </div>
                                        <h5 class="ps-product__title">
                                            <a href="<?php echo e(route('product.details', $deal_product->slug)); ?>">
                                                <?php echo e($deal_product->name); ?>

                                            </a>
                                        </h5>
                                        <div class="ps-product__desc">
                                            <p><?php echo $deal_product->short_description; ?></p>
                                        </div>
                                        <?php if(!empty($deal_product->unit_discount_price)): ?>
                                            <div class="ps-product__meta">
                                                <span
                                                    class="ps-product__price sale">৳<?php echo e($deal_product->unit_discount_price); ?></span>
                                                <span class="ps-product__del">৳<?php echo e($deal_product->unit_price); ?></span>
                                            </div>
                                        <?php else: ?>
                                            <div class="ps-product__meta">
                                                <span
                                                    class="ps-product__price sale">৳<?php echo e($deal_product->unit_price); ?></span>
                                            </div>
                                        <?php endif; ?>

                                        

                                        <div class="ps-product__feature">
                                            <?php if(!empty($deal_product->stock) && $deal_product->stock > 0): ?>
                                                <div class="ps-product__badge mb-0"><span
                                                        class="ps-badge bg-success"><?php echo e($deal_product->stock); ?> In
                                                        Stock</span></div>
                                            <?php else: ?>
                                                <div class="ps-product__badge mb-0"><span
                                                        class="ps-badge ps-badge--outstock">Out Of
                                                        Stock</span></div>
                                            <?php endif; ?>


                                            <?php if(!empty($deal_product->unit_discount_price)): ?>
                                                <div class="ps-product__meta py-3">
                                                    <span
                                                        class="ps-product__price sale">৳<?php echo e($deal_product->unit_discount_price); ?></span>
                                                    <span
                                                        class="ps-product__del">৳<?php echo e($deal_product->unit_price); ?></span>
                                                </div>
                                            <?php else: ?>
                                                <div class="ps-product__meta py-3">
                                                    <span
                                                        class="ps-product__price sale">৳<?php echo e($deal_product->unit_price); ?></span>
                                                </div>
                                            <?php endif; ?>

                                            <div class="ps-product__quantity">
                                                <h6>Quantity</h6>
                                                <div class="def-number-input number-input safari_only">
                                                    <button class="minus"
                                                        onclick="this.parentNode.querySelector('input[type=number]').stepDown()"><i
                                                            class="icon-minus"></i></button>
                                                    <input class="quantity" min="1" name="quantity"
                                                        value="1" type="number"
                                                        data-product_id="<?php echo e($deal_product->id); ?>" />
                                                    <button class="plus"
                                                        onclick="this.parentNode.querySelector('input[type=number]').stepUp()"><i
                                                            class="icon-plus"></i></button>
                                                </div>
                                            </div>

                                            <a class="ps-btn ps-btn--warning add_to_cart_btn_product_single"
                                                data-product_id="<?php echo e($deal_product->id); ?>" href="#">Add to
                                                cart</a>

                                            <ul class="ps-product__bundle">
                                                <li><i class="icon-bag2"></i>Full cash on delivery</li>
                                                <li><i class="icon-truck"></i>Inside Dhaka-70 TK (24-48 hrs)</li>
                                                <li><i class="icon-truck"></i>Outside Dhaka-150 TK (2-4 Days)</li>
                                                </li>
                                                <li><i class="icon-truck"></i>Dhaka Sub-area-100 TK </li>
                                                <li><i class="icon-location"></i>
                                                    Sub-areas: <br>
                                                    <span class="pt-2"
                                                        style="position: relative;left: 32px;width: 94%;display: inline-block;">Keraniganj,
                                                        Tangi, Savar, Gazipur, Narayanganj, Asulia (2-4 Days)</span>
                                                </li>
                                            </ul>
                                        </div>


                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/frontend/layouts/HomeQuickViewModal.blade.php ENDPATH**/ ?>