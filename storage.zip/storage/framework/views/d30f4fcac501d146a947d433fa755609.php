<?php
    $cartItems = Cart::instance('cart')->content();
    $subTotal = Cart::instance('cart')->subtotal();
?>
    <ul class="ps-cart__items">
        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="ps-cart__item">
                <div class="ps-product--mini-cart">
                    <a class="ps-product__thumbnail" href="<?php echo e(route('product.details', $item->model->slug)); ?>">
                        <img src="<?php echo e(asset('storage/' . $item->model->thumbnail)); ?>" alt="alt" />
                    </a>
                    <div class="ps-product__content p-0">
                        <a class="ps-product__name" href="<?php echo e(route('product.details', $item->model->slug)); ?>">
                            <?php echo e($item->model->name); ?></a>
                        <p class="ps-product__meta">
                            <span class="ps-product__price"><?php echo e($item->qty); ?>  X  </span>
                            <span class="ps-product__price">৳<?php echo e($item->price); ?></span>
                        </p>
                    </div>
                    <a class="ps-product__remove delete" href="<?php echo e(route('cart.destroy',$item->rowId )); ?>">
                        <i class="icon-cross"></i>
                    </a>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
    <div class="ps-cart__total">
        <span>Subtotal </span>
        <span>৳<?php echo e($subTotal); ?></span>
    </div>
    <div class="ps-cart__footer d-flex">
        <a class="btn btn-outline-primary mr-2" href="<?php echo e(route('cart')); ?>">View Cart
        </a>
        <a class="btn btn-primary" href="<?php echo e(route('checkout')); ?>">Checkout</a>
    </div>

<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/frontend/pages/cart/partials/minicart.blade.php ENDPATH**/ ?>