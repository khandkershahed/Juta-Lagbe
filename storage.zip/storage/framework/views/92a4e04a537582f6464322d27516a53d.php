<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <base href="../../../">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="format-detection" content="telephone=no">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <link href="<?php echo e(asset('storage/' . optional($setting)->site_favicon)); ?>" rel="apple-touch-icon-precomposed">
    <link href="<?php echo e(asset('storage/' . optional($setting)->site_favicon)); ?>" rel="shortcut icon" type="image/png">
    <meta name="title" content="<?php echo e(optional($setting)->site_title ?: config('app.name', 'E-Commerce')); ?>" />
    <meta name="description" content="<?php echo e(optional($setting)->meta_description ?: config('app.name')); ?>" />

    <!-- Open Graph / Facebook -->
    <meta property="og:type" content="website" />
    <meta property="og:url" content="<?php echo e(optional($setting)->site_url ?: config('app.url')); ?>" />
    <meta property="og:title" content="<?php echo e(optional($setting)->site_title ?: config('app.name', 'E-Commerce')); ?>" />
    <meta property="og:description" content="<?php echo e(optional($setting)->meta_description ?: config('app.name')); ?>" />
    <meta property="og:image"
        content="<?php echo e(optional($setting)->site_logo && file_exists(public_path('storage/' . optional($setting)->site_logo)) ? asset('storage/' . optional($setting)->site_logo) : asset('frontend/images/brandPage-logo-no-img(217-55).jpg')); ?>" />

    <!-- Twitter -->
    <meta property="twitter:card" content="summary_large_image" />
    <meta property="twitter:url" content="<?php echo e(optional($setting)->site_url ?: config('app.url')); ?>" />
    <meta property="twitter:title"
        content="<?php echo e(optional($setting)->site_title ?: config('app.name', 'E-Commerce')); ?>" />
    <meta property="twitter:description" content="<?php echo e(optional($setting)->meta_description ?: config('app.name')); ?>" />
    <meta property="twitter:image"
        content="<?php echo e(optional($setting)->site_logo && file_exists(public_path('storage/' . optional($setting)->site_logo)) ? asset('storage/' . optional($setting)->site_logo) : asset('frontend/images/brandPage-logo-no-img(217-55).jpg')); ?>" />

    <title><?php echo e(optional($setting)->site_title ?: config('app.name', 'E-Commerce')); ?></title>

    


    <link href="<?php echo e(asset('admin/assets/plugins/global/plugins.bundle.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('admin/assets/css/style.bundle.css')); ?>" rel="stylesheet" type="text/css" />

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

</head>



<body id="kt_body" class="bg-body">


    <div class="d-flex flex-column flex-root">
        <?php echo e($slot); ?>

    </div>



    <script>
        var hostUrl = "assets/";
    </script>

    <script src="<?php echo e(asset('admin/assets/plugins/global/plugins.bundle.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/scripts.bundle.js')); ?>"></script>


    <script src="<?php echo e(asset('admin/assets/js/custom/authentication/sign-in/general.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/assets/js/custom/apps/user-management/users/view/update-password.js')); ?>"></script>

		<?php echo $__env->yieldPushContent('scripts'); ?>

</body>


</html>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/admin/layouts/guest.blade.php ENDPATH**/ ?>