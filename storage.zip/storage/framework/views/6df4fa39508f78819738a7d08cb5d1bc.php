<?php if (isset($component)) { $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $attributes; } ?>
<?php $component = App\View\Components\AdminAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminAppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Product Add')]); ?>
    <style>
        .image-input-empty {
            background-image: url(<?php echo e(asset('admin/assets/media/svg/files/blank-image.svg')); ?>);
        }

        /* Custom Multi file upload */
        .img-thumb {
            border: 2px solid none;
            border-radius: 3px;
            padding: 1px;
            cursor: pointer;
            width: 70px;
            height: 60px;
            border-radius: 0.475rem;
        }


        .img-thumb-wrapper {
            display: inline-block;
            margin: 1rem 1rem 0 0;
        }


        .remove {
            display: block;
            background: #cf054f;
            border: 1px solid none;
            color: white;
            text-align: center;
            cursor: pointer;
            font-size: 12px;
            padding: 2px 5px;
        }


        .remove:hover {
            background: white;
            color: black;
        }


        .dropzone-field {
            border: 1px dashed #009ef7;
            display: flex;
            flex-wrap: wrap;
            /* Allow multiple images in a row */
            align-items: center;
            border-radius: 4px;
            padding: 10px 5px;
            justify-content: center;
        }


        #files {
            display: none;
        }


        .custom-file-upload {
            border: 0px solid #ccc;
            padding: 6px 12px;
            cursor: pointer;
            background-color: transparent;
        }


        .custom-file-upload i {
            margin-right: 5px;
        }

        /* Custom Multi file upload */
    </style>
    <div id="kt_app_content_container" class="app-container container-xxl">
        <form id="kt_ecommerce_add_product_form" method="post" action="<?php echo e(route('admin.product.store')); ?>"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="row">
                <div class="gap-7 gap-lg-10 col-9">
                    <ul class="nav nav-custom nav-tabs nav-line-tabs nav-line-tabs-2x border-0 fs-4 fw-semibold mb-n2">
                        <li class="nav-item">
                            <a class="nav-link text-active-primary pb-4 active" data-bs-toggle="tab"
                                href="#kt_ecommerce_add_product_general">General</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-active-primary pb-4" data-bs-toggle="tab"
                                href="#kt_ecommerce_add_product_media">Media</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-active-primary pb-4" data-bs-toggle="tab"
                                href="#kt_ecommerce_add_product_advanced">Inventory</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-active-primary pb-4" data-bs-toggle="tab"
                                href="#kt_ecommerce_add_product_price">Pricing</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link text-active-primary pb-4" data-bs-toggle="tab"
                                href="#kt_ecommerce_add_product_meta">Meta Options</a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane fade show active" id="kt_ecommerce_add_product_general" role="tab-panel">
                            <div class="d-flex flex-column gap-7 gap-lg-10">
                                
                                <div class="card card-flush py-4 mt-3">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>General</h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div class="mb-5 fv-row">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Product Name <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['type' => 'text','name' => 'name','class' => 'form-control mb-2','placeholder' => 'Product name recommended','value' => old('name')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'name','class' => 'form-control mb-2','placeholder' => 'Product name recommended','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name'))]); ?>
                                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                                            <div class="text-muted fs-7">
                                                A product name is and recommended to be unique.
                                            </div>
                                        </div>
                                        <div class="mb-5 fv-row">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Tags <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <input class="form-control" name="tags" id="product_Tags"
                                                value="old('tags')" />
                                        </div>
                                        <div class="mb-5 fv-row">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Short Description <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginal8a993d6e029bdac6bb7f4547b7034bf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a993d6e029bdac6bb7f4547b7034bf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.textarea','data' => ['id' => 'short_description','name' => 'short_description','placeholder' => 'Add Product Short Description','class' => 'form-control mb-2','cols' => '30','rows' => '3']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'short_description','name' => 'short_description','placeholder' => 'Add Product Short Description','class' => 'form-control mb-2','cols' => '30','rows' => '3']); ?><?php echo old('short_description'); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a993d6e029bdac6bb7f4547b7034bf0)): ?>
<?php $attributes = $__attributesOriginal8a993d6e029bdac6bb7f4547b7034bf0; ?>
<?php unset($__attributesOriginal8a993d6e029bdac6bb7f4547b7034bf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a993d6e029bdac6bb7f4547b7034bf0)): ?>
<?php $component = $__componentOriginal8a993d6e029bdac6bb7f4547b7034bf0; ?>
<?php unset($__componentOriginal8a993d6e029bdac6bb7f4547b7034bf0); ?>
<?php endif; ?>
                                        </div>
                                        <div class="mb-5 fv-row">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Product Overview <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <textarea name="overview" class="ckeditor"><?php echo old('overview'); ?></textarea>
                                            <div class="text-muted fs-7">
                                                Add product overview here.
                                            </div>
                                        </div>
                                        <div class="mb-5 fv-row">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Product Description <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <textarea name="description" class="ckeditor"><?php echo old('description'); ?></textarea>
                                            <div class="text-muted fs-7">
                                                Add product description here.
                                            </div>
                                        </div>
                                        <div class="mb-5 fv-row">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Product
                                                Specification <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <textarea name="specification" class="ckeditor"><?php echo old('specification'); ?></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="kt_ecommerce_add_product_media" role="tab-panel">
                            <div class="d-flex flex-column gap-7 gap-lg-10">
                                
                                <div class="card card-flush py-4">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>Media</h2>
                                        </div>
                                    </div>
                                    <div class="card-body py-4 mt-3">
                                        <div class="row">
                                            <div class="col-4">
                                                <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => '','class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => '','class' => 'form-label']); ?>Set the product
                                                    thumbnail image. Only *.png, *.jpg and *.jpeg image
                                                    files are accepted <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                                <div class="image-input image-input-empty" data-kt-image-input="true"
                                                    style="width: auto;
                                                    background-size: contain;
                                                    border: 1px solid #009ae5;">
                                                    <div class="image-input-wrapper w-100px h-70px"></div>

                                                    <label
                                                        class="btn btn-icon btn-circle btn-color-muted btn-active-color-primary w-25px h-25px bg-body shadow"
                                                        data-kt-image-input-action="change" data-bs-toggle="tooltip"
                                                        data-bs-dismiss="click" title="Change avatar">
                                                        <i class="bi bi-pencil-fill fs-7"></i>

                                                        <input type="file" name="thumbnail"
                                                            accept=".png, .jpg, .jpeg" />
                                                        <input type="hidden" name="avatar_remove" />
                                                    </label>

                                                    <span
                                                        class="btn btn-icon btn-circle btn-color-muted btn-active-color-primary w-25px h-25px bg-body shadow"
                                                        data-kt-image-input-action="cancel" data-bs-toggle="tooltip"
                                                        data-bs-dismiss="click" title="Cancel avatar">
                                                        <i class="bi bi-x fs-2"></i>
                                                    </span>

                                                    <span
                                                        class="btn btn-icon btn-circle btn-color-muted btn-active-color-primary w-25px h-25px bg-body shadow"
                                                        data-kt-image-input-action="remove" data-bs-toggle="tooltip"
                                                        data-bs-dismiss="click" title="Remove avatar">
                                                        <i class="bi bi-x fs-2"></i>
                                                    </span>
                                                </div>
                                            </div>
                                            
                                            <div class="col-8">
                                                <div class="fv-row pt-5">
                                                    <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => '','class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => '','class' => 'form-label']); ?>Add the
                                                        product multi image <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                                    <div class="dropzone-field">
                                                        <label for="files" class="custom-file-upload">
                                                            <div class="d-flex align-items-center">
                                                                <p class="mb-0"><i
                                                                        class="bi bi-file-earmark-arrow-up text-primary fs-3x"></i>
                                                                </p>
                                                                <h5 class="mb-0">Drop files here or click to upload.
                                                                    <br>
                                                                    <span class="text-muted"
                                                                        style="font-size: 10px">Upload 10 File</span>
                                                                </h5>
                                                            </div>
                                                        </label>
                                                        <input type="file" id="files" name="multi_images[]"
                                                            multiple class="form-control" style="display: none;"
                                                            onchange="console.log(this.selected.value)" />
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-12">
                                                <div class="fv-row pt-5">
                                                    <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'video_link','class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'video_link','class' => 'form-label']); ?>Product
                                                        Video
                                                        Link <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                                    <input type="text" name="video_link" class="form-control mb-2"
                                                        placeholder="Product Video Link" id="video_link"
                                                        value="<?php echo e(old('video_link')); ?>">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="kt_ecommerce_add_product_advanced" role="tab-panel">
                            <div class="d-flex flex-column gap-7 gap-lg-10">
                                
                                <div class="card card-flush py-4 mt-3">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>Inventory</h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0 row">
                                        <div class="mb-10 fv-row col-6">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>SKU Code <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['type' => 'text','name' => 'sku_code','class' => 'form-control mb-2','placeholder' => 'SKU Number','value' => old('sku_code')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'sku_code','class' => 'form-control mb-2','placeholder' => 'SKU Number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('sku_code'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                                                <div class="text-muted fs-7">Enter the product SKU.</div>
                                        </div>
                                        <div class="mb-10 fv-row col-6">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>MF Code <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['type' => 'text','name' => 'mf_code','class' => 'form-control mb-2','placeholder' => 'MF Number','value' => old('mf_code')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'mf_code','class' => 'form-control mb-2','placeholder' => 'MF Number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('mf_code'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                                                <div class="text-muted fs-7">Enter the product MF.</div>
                                        </div>

                                        <div class="mb-10 fv-row col-12">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Barcode <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['type' => 'text','name' => 'barcode_id','class' => 'form-control mb-2','placeholder' => 'Barcode Number','value' => old('barcode_id')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'text','name' => 'barcode_id','class' => 'form-control mb-2','placeholder' => 'Barcode Number','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('barcode_id'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                                                <div class="text-muted fs-7">
                                                    Enter the product barcode number.
                                                </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="kt_ecommerce_add_product_price" role="tab-panel">
                            <div class="d-flex flex-column gap-7 gap-lg-10">
                                
                                <div class="card card-flush py-4 mt-3">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>Box Pricing</h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0 row">
                                        
                                        <div class="mb-5 fv-row col-4">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Price <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['type' => 'number','name' => 'unit_price','id' => 'unit_price','class' => 'form-control mb-2','placeholder' => 'how much the unit price','value' => old('unit_price'),'readonly' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','name' => 'unit_price','id' => 'unit_price','class' => 'form-control mb-2','placeholder' => 'how much the unit price','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('unit_price')),'readonly' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                                                <div class="text-muted fs-7">How much unit price.</div>
                                        </div>
                                        <div class="mb-5 fv-row col-4">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Unit Discount <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['type' => 'number','name' => 'unit_discount_price','id' => 'unit_discount','class' => 'form-control mb-2','placeholder' => 'how much the unit discount price','value' => old('unit_discount_price'),'readonly' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','name' => 'unit_discount_price','id' => 'unit_discount','class' => 'form-control mb-2','placeholder' => 'how much the unit discount price','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('unit_discount_price')),'readonly' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                                                <div class="text-muted fs-7">How much unit discount price.</div>
                                        </div>
                                        <div class="mb-5 fv-row col-4">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Stock <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['type' => 'number','name' => 'stock','id' => 'stock','class' => 'form-control mb-2','placeholder' => 'how much thestock','value' => old('stock')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','name' => 'stock','id' => 'stock','class' => 'form-control mb-2','placeholder' => 'how much thestock','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('stock'))]); ?>
                                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                                                <div class="text-muted fs-7">How much stock. Eg: 50</div>
                                        </div>
                                        <div class="mb-5 fv-row col-4">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Vat <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['type' => 'number','name' => 'vat','id' => 'vat','class' => 'form-control mb-2','placeholder' => 'how much the vat','value' => old('vat')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','name' => 'vat','id' => 'vat','class' => 'form-control mb-2','placeholder' => 'how much the vat','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('vat'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                                                <div class="text-muted fs-7">How much vat. Eg: 5%</div>
                                        </div>
                                        <div class="mb-5 fv-row col-4">
                                            <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Tax <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                            <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['type' => 'number','name' => 'tax','id' => 'tax','class' => 'form-control mb-2','placeholder' => 'how much the tax ','value' => old('tax')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','name' => 'tax','id' => 'tax','class' => 'form-control mb-2','placeholder' => 'how much the tax ','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('tax'))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                                                <div class="text-muted fs-7">How much tax Eg: 5%</div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="tab-pane fade" id="kt_ecommerce_add_product_meta" role="tab-panel">
                            <div class="d-flex flex-column gap-7 gap-lg-10">
                                
                                <div class="card card-flush py-4 mt-3">
                                    <div class="card-header">
                                        <div class="card-title">
                                            <h2>Meta Options</h2>
                                        </div>
                                    </div>
                                    <div class="card-body pt-0">
                                        <div class="mb-10">
                                            <div class="mb-5 fv-row">
                                                <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Product Meta
                                                    Title <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                                <input class="form-control" name="meta_title" type="text"
                                                    placeholder="Meta tag name" id="meta_title"
                                                    :value="old('meta_title')" />
                                            </div>
                                            <div class="text-muted fs-7">
                                                Add Product Meta Title.
                                            </div>
                                        </div>
                                        <div class="mb-10">
                                            <div class="mb-5 fv-row">
                                                <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Meta
                                                    Description <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                                <textarea name="meta_description" class="ckeditor"><?php echo old('meta_description'); ?></textarea>
                                                <div class="text-muted fs-7">
                                                    Add Meta Meta details.
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <div class="mb-5 fv-row">
                                                <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Meta Tag
                                                    Keywords <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                                <input class="form-control" name="meta_keywords"
                                                    placeholder="Meta tag keywords" id="meta_keywords"
                                                    :value="old('meta_keywords')" />
                                                <div class="text-muted fs-7">
                                                    Add product Meta tag keywords.
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="d-flex justify-content-end mt-10">
                        <a href="<?php echo e(route('admin.product.index')); ?>" class="btn btn-danger me-5">
                            Back To Product List
                        </a>
                        
                        <button type="submit" class="btn btn-primary">
                            <span class="indicator-label"> Save Changes </span>
                            </span>
                        </button>
                    </div>
                </div>
                <div class="gap-7 gap-lg-10 mb-7  col-3">
                    
                    <div class="card card-flush py-4 mb-6">
                        <div class="card-header">
                            <div class="card-title">
                                <h2>Status</h2>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <?php if (isset($component)) { $__componentOriginalff6880852fb7a3f71461ce3b06af5a25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.select-option','data' => ['id' => 'kt_ecommerce_add_product_status_select','class' => 'form-select mb-2','dataControl' => 'select2','dataHideSearch' => 'true','name' => 'status','dataPlaceholder' => 'Select an option']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'kt_ecommerce_add_product_status_select','class' => 'form-select mb-2','data-control' => 'select2','data-hide-search' => 'true','name' => 'status','data-placeholder' => 'Select an option']); ?>
                                <option></option>
                                <option value="published" selected>Published</option>
                                <option value="draft">Draft</option>
                                <option value="inactive">Inactive</option>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $attributes = $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $component = $__componentOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
                            <div class="text-muted fs-7">Set the product status.</div>
                        </div>
                    </div>
                    
                    
                    <div class="card card-flush py-4">
                        <div class="card-header">
                            <div class="card-title">
                                <h2>Category</h2>
                            </div>
                        </div>
                        <div class="card-body pt-0">
                            <div class="fv-row">
                                <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'brand_id','class' => 'col-form-label required fw-bold fs-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'brand_id','class' => 'col-form-label required fw-bold fs-6']); ?>
                                    <?php echo e(__('Select Brand')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalff6880852fb7a3f71461ce3b06af5a25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.select-option','data' => ['id' => 'brand_id','class' => 'form-select mb-2','name' => 'brand_id','dataControl' => 'select2','dataPlaceholder' => 'Select an option','dataAllowClear' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'brand_id','class' => 'form-select mb-2','name' => 'brand_id','data-control' => 'select2','data-placeholder' => 'Select an option','data-allow-clear' => 'true']); ?>
                                    <option></option>
                                    <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $attributes = $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $component = $__componentOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
                            </div>
                            <div class="fv-row">
                                <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'category_id','class' => 'col-form-label required fw-bold fs-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'category_id','class' => 'col-form-label required fw-bold fs-6']); ?>
                                    <?php echo e(__('Select Category')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                <?php if (isset($component)) { $__componentOriginalff6880852fb7a3f71461ce3b06af5a25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.select-option','data' => ['id' => 'category_id','class' => 'form-control select mb-2','name' => 'category_id[]','multiple' => true,'multiselectSearch' => 'true','multiselectSelectAll' => 'true','dataControl' => 'select2','dataPlaceholder' => 'Select an option','dataAllowClear' => 'true']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'category_id','class' => 'form-control select mb-2','name' => 'category_id[]','multiple' => true,'multiselect-search' => 'true','multiselect-select-all' => 'true','data-control' => 'select2','data-placeholder' => 'Select an option','data-allow-clear' => 'true']); ?>
                                    <?php echo $categoriesOptions; ?>

                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $attributes = $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $component = $__componentOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
                            </div>
                            <div class="fv-row">
                                <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'color','class' => 'col-form-label required fw-bold fs-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'color','class' => 'col-form-label required fw-bold fs-6']); ?>
                                    <?php echo e(__('Add Color')); ?>

                                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                                <!-- Input element for Tagify -->
                                <input class="form-control d-flex align-items-center" name="color"
                                    value="<?php echo e(old('color')); ?>" id="color" />
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
        </form>
    </div>
    <?php $__env->startPush('scripts'); ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // The DOM elements you wish to replace with Tagify
                var input1 = document.querySelector("#product_Tags");
                var input2 = document.querySelector("#product_meta_tags");
                var input3 = document.querySelector("#product_meta_keyword");
                var input4 = document.querySelector("#color");

                // Initialize Tagify components on the above inputs
                new Tagify(input1);
                new Tagify(input2);
                new Tagify(input3);
                new Tagify(input4);
            });



            // Product dimension box
            document.addEventListener('DOMContentLoaded', function() {
                const lengthInput = document.getElementById('length');
                const widthInput = document.getElementById('width');
                const heightInput = document.getElementById('height');
                const weightInput = document.getElementById('weight');

                const dimensionPreview = document.getElementById('dimensionPreview');

                function updatePreview() {
                    const length = lengthInput.value || 0;
                    const width = widthInput.value || 0;
                    const height = heightInput.value || 0;
                    const weight = weightInput.value || 0;

                    dimensionPreview.textContent =
                        `${length} cm X ${width} cm X ${height} cm X ${weight} gm`;
                }

                // Attach the event listener to each input field
                lengthInput.addEventListener('input', updatePreview);
                widthInput.addEventListener('input', updatePreview);
                heightInput.addEventListener('input', updatePreview);
                weightInput.addEventListener('input', updatePreview);
            });

            // Define color mapping
            var colorMapping = {
                'Red': '#FF5733',
                'Green': '#33FF57',
                'Blue': '#3357FF',
                'Yellow': '#FFFF33',
                'Purple': '#A933FF',
                'Orange': '#FF8C33',
                'Pink': '#FF33B5',
                'Brown': '#8C4C33',
                'Gray': '#BEBEBE',
                'Black': '#000000',
                'White': '#FFFFFF',
                'Cyan': '#00FFFF',
                'Magenta': '#FF00FF',
                'Lime': '#00FF00',
                'Teal': '#008080',
                'Olive': '#808000',
                'Navy': '#000080',
                'Maroon': '#800000',
                'Silver': '#C0C0C0',
                'Gold': '#FFD700',
                'Coral': '#FF7F50',
                'Indigo': '#4B0082',
                'Turquoise': '#40E0D0',
                'Salmon': '#FA8072'
            };

            // Convert colorMapping to an array of objects for Tagify dropdown
            var colorArray = Object.keys(colorMapping).map(key => ({
                value: key,
                color: colorMapping[key]
            }));

            // Initialize Tagify on the input element
            var tagify = new Tagify(document.querySelector('#kt_tagify_color'), {
                delimiters: null,
                templates: {
                    tag: function(tagData) {
                        const color = colorMapping[tagData.value] || '#cccccc'; // Default color if not found
                        try {
                            return `<tag title='${tagData.value}' contenteditable='false' spellcheck="false"
                    class='tagify__tag ${tagData.class ? tagData.class : ""}' ${this.getAttributes(tagData)}
                    style="background-color: ${color}; border: none; display: flex; align-items: center; padding: 0;">
                        <x title='remove tag' class='tagify__tag__removeBtn'></x>
                        <div class="d-flex align-items-center" style="width: 25px; height: 25px; background-color: ${color}; border-radius: 4px; margin-right: 8px;"></div>
                        <span class='tagify__tag-text'>${tagData.value}</span>
                    </tag>`;
                        } catch (err) {
                            console.error('Error in tag template:', err);
                        }
                    },

                    dropdownItem: function(tagData) {
                        const color = colorMapping[tagData.value] || '#cccccc'; // Default color if not found
                        try {
                            return `<div ${this.getAttributes(tagData)} class='tagify__dropdown__item ${tagData.class ? tagData.class : ""}'
                    style="background-color: white; color: black; display: flex; align-items: center; padding: 4px 8px;">
                        <div style="width: 25px; height: 25px; background-color: ${color}; border-radius: 4px; margin-right: 8px;"></div>
                        <span>${tagData.value}</span>
                    </div>`;
                        } catch (err) {
                            console.error('Error in dropdown item template:', err);
                        }
                    }
                },
                // Remove whitelist to allow all colors to be shown in dropdown
                enforceWhitelist: false,
                // Display dropdown items based on the colorMapping array
                whitelist: colorArray,
                dropdown: {
                    enabled: 1, // Show the dropdown as the user types
                    classname: 'extra-properties' // Custom class for the suggestions dropdown
                }
            });

            // Show all color options when the input is clicked
            var inputElement = document.querySelector('#kt_tagify_color');

            inputElement.addEventListener('click', function() {
                tagify.dropdown.show.call(tagify);
            });

            // Add the first 2 tags and make them readonly
            // var tagsToAdd = tagify.settings.whitelist.slice(0, 2);
            // tagify.addTags(tagsToAdd);



            // Product Pricing
            function calculatePrices() {
                const boxContains = parseFloat(document.getElementById('box_contains').value) || 0;
                const boxPrice = parseFloat(document.getElementById('box_price').value) || 0;
                const boxDiscountPrice = parseFloat(document.getElementById('box_discount_price').value) || 0;

                const unitPrice = boxContains ? (boxPrice / boxContains).toFixed(2) : 0;
                const unitDiscount = boxContains ? (boxDiscountPrice / boxContains).toFixed(2) : 0;

                document.getElementById('unit_price').value = unitPrice;
                document.getElementById('unit_discount').value = unitDiscount;
            }

            document.getElementById('box_contains').addEventListener('input', calculatePrices);
            document.getElementById('box_price').addEventListener('input', calculatePrices);
            document.getElementById('box_discount_price').addEventListener('input', calculatePrices);

            // Product Multiimage Submit
            var uploadedDocumentMap = {}; // Assuming you have this variable defined somewhere

            var myDropzone = new Dropzone("#product_multiimage", {
                url: "<?php echo e(route('admin.product.store')); ?>",
                paramName: "multi_image", // The name that will be used to transfer the file
                uploadMultiple: true,
                parallelUploads: 10,
                maxFiles: 10,
                maxFilesize: 10, // MB
                addRemoveLinks: true,
                accept: function(file, done) {
                    console.log(file);
                    $('#kt_ecommerce_add_product_form').append(
                        '<input type="hidden" name="document[ value="<?php echo e(old('document')); ?>"]" value="' + file
                        .file + '">');
                    done();
                },
                method: "post",
            });

            document.getElementById('kt_ecommerce_add_product_form').addEventListener('submit', function(event) {
                var formData = new FormData(this);
                console.log(formData);
            });
            // textEditor
            class CKEditorInitializer {
                constructor(className) {
                    this.className = className;
                }

                initialize() {
                    const elements = document.querySelectorAll(this.className);
                    elements.forEach(element => {
                        ClassicEditor
                            .create(element)
                            .then(editor => {
                                console.log('CKEditor initialized:', editor);
                            })
                            .catch(error => {
                                console.error('CKEditor initialization error:', error);
                            });
                    });
                }
            }

            // Example usage:
            const ckEditorInitializer = new CKEditorInitializer('.ckeditor');
            ckEditorInitializer.initialize();
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $attributes = $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $component = $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/admin/pages/product/create.blade.php ENDPATH**/ ?>