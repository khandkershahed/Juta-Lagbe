
<?php if (isset($component)) { $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07 = $attributes; } ?>
<?php $component = App\View\Components\AdminAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminAppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Brand Edit')]); ?>
    <div class="card card-flash">
        <!--begin::Card header-->
        <div class="card-header mt-6">
            <div class="card-title"></div>

            <!--begin::Card toolbar-->
            <div class="card-toolbar">
                <!--begin::Button-->
                <a href="<?php echo e(route('admin.brands.index')); ?>" class="btn btn-light-info">
                    <!--begin::Svg Icon | path: brands/duotune/general/gen035.svg-->
                    <span class="svg-icon svg-icon-3">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"
                            fill="none">
                            <rect opacity="0.3" x="2" y="2" width="20" height="20" rx="5"
                                fill="currentColor" />
                            <rect x="10.8891" y="17.8033" width="12" height="2" rx="1"
                                transform="rotate(-90 10.8891 17.8033)" fill="currentColor" />
                            <rect x="6.01041" y="10.9247" width="12" height="2" rx="1"
                                fill="currentColor" />
                        </svg>
                    </span>
                    <!--end::Svg Icon-->Back to the list
                </a>
            </div>
        </div>
        <div class="card-body pt-0">
            <!--begin::Form-->
            <form class="form" action="<?php echo e(route('admin.brands.update', $brand->id)); ?>" method="POST"
                enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <!--begin::Input group-->
                <div class="row">
                    <div class="col-lg-6 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'name','class' => 'col-form-label fw-bold fs-6 required']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'name','class' => 'col-form-label fw-bold fs-6 required']); ?><?php echo e(__('Name')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['id' => 'name','type' => 'text','name' => 'name','value' => old('name', $brand->name),'placeholder' => 'Enter the Name','required' => true]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'name','type' => 'text','name' => 'name','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('name', $brand->name)),'placeholder' => 'Enter the Name','required' => true]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                    </div>

                    <div class="col-lg-6 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'url','class' => 'col-form-label fw-bold fs-6 required']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'url','class' => 'col-form-label fw-bold fs-6 required']); ?><?php echo e(__('Url')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['id' => 'url','type' => 'url','name' => 'url','value' => old('url', $brand->url),'placeholder' => 'Enter the Url']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'url','type' => 'url','name' => 'url','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('url', $brand->url)),'placeholder' => 'Enter the Url']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                    </div>

                    <div class="col-lg-4 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'logo','class' => 'col-form-label fw-bold fs-6 ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'logo','class' => 'col-form-label fw-bold fs-6 ']); ?><?php echo e(__('Logo')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal3e938978070c04547663785a40685fbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e938978070c04547663785a40685fbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.file-input','data' => ['id' => 'logo','name' => 'logo','source' => asset('storage/'.$brand->logo),'value' => old('logo', $brand->logo)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.file-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'logo','name' => 'logo','source' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset('storage/'.$brand->logo)),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('logo', $brand->logo))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e938978070c04547663785a40685fbe)): ?>
<?php $attributes = $__attributesOriginal3e938978070c04547663785a40685fbe; ?>
<?php unset($__attributesOriginal3e938978070c04547663785a40685fbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e938978070c04547663785a40685fbe)): ?>
<?php $component = $__componentOriginal3e938978070c04547663785a40685fbe; ?>
<?php unset($__componentOriginal3e938978070c04547663785a40685fbe); ?>
<?php endif; ?>
                    </div>
                    <div class="col-lg-4 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'image','class' => 'col-form-label fw-bold fs-6 required']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'image','class' => 'col-form-label fw-bold fs-6 required']); ?><?php echo e(__('Thumbnail Image')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal3e938978070c04547663785a40685fbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e938978070c04547663785a40685fbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.file-input','data' => ['id' => 'image','name' => 'image','source' => asset('storage/'.$brand->image),'value' => old('image', $brand->image)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.file-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'image','name' => 'image','source' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset('storage/'.$brand->image)),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('image', $brand->image))]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e938978070c04547663785a40685fbe)): ?>
<?php $attributes = $__attributesOriginal3e938978070c04547663785a40685fbe; ?>
<?php unset($__attributesOriginal3e938978070c04547663785a40685fbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e938978070c04547663785a40685fbe)): ?>
<?php $component = $__componentOriginal3e938978070c04547663785a40685fbe; ?>
<?php unset($__componentOriginal3e938978070c04547663785a40685fbe); ?>
<?php endif; ?>
                    </div>
                    <div class="col-lg-4 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'banner_image','class' => 'col-form-label fw-bold fs-6 ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'banner_image','class' => 'col-form-label fw-bold fs-6 ']); ?><?php echo e(__('Banner Image')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal3e938978070c04547663785a40685fbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3e938978070c04547663785a40685fbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.file-input','data' => ['id' => 'banner_image','source' => asset('storage/'.$brand->banner_image),'value' => old('banner_image', $brand->banner_image),'name' => 'banner_image']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.file-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'banner_image','source' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(asset('storage/'.$brand->banner_image)),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('banner_image', $brand->banner_image)),'name' => 'banner_image']); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3e938978070c04547663785a40685fbe)): ?>
<?php $attributes = $__attributesOriginal3e938978070c04547663785a40685fbe; ?>
<?php unset($__attributesOriginal3e938978070c04547663785a40685fbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3e938978070c04547663785a40685fbe)): ?>
<?php $component = $__componentOriginal3e938978070c04547663785a40685fbe; ?>
<?php unset($__componentOriginal3e938978070c04547663785a40685fbe); ?>
<?php endif; ?>
                    </div>
                    <div class="col-lg-8 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'description','class' => 'col-form-label fw-bold fs-6 ']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'description','class' => 'col-form-label fw-bold fs-6 ']); ?><?php echo e(__('Description')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>

                        <?php if (isset($component)) { $__componentOriginal8a993d6e029bdac6bb7f4547b7034bf0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal8a993d6e029bdac6bb7f4547b7034bf0 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.textarea','data' => ['id' => 'description','name' => 'description']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.textarea'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'description','name' => 'description']); ?><?php echo e(old('description', $brand->description)); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal8a993d6e029bdac6bb7f4547b7034bf0)): ?>
<?php $attributes = $__attributesOriginal8a993d6e029bdac6bb7f4547b7034bf0; ?>
<?php unset($__attributesOriginal8a993d6e029bdac6bb7f4547b7034bf0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8a993d6e029bdac6bb7f4547b7034bf0)): ?>
<?php $component = $__componentOriginal8a993d6e029bdac6bb7f4547b7034bf0; ?>
<?php unset($__componentOriginal8a993d6e029bdac6bb7f4547b7034bf0); ?>
<?php endif; ?>
                    </div>
                    <div class="col-lg-4 mb-7">
                        <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['for' => 'status','class' => 'col-form-label required fw-bold fs-6']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => 'status','class' => 'col-form-label required fw-bold fs-6']); ?>
                            <?php echo e(__('Select a Status ')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginalff6880852fb7a3f71461ce3b06af5a25 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.select-option','data' => ['id' => 'status','name' => 'status','dataHideSearch' => 'true','dataPlaceholder' => 'Select an option']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.select-option'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['id' => 'status','name' => 'status','data-hide-search' => 'true','data-placeholder' => 'Select an option']); ?>
                            <option></option>
                            <option value="active" <?php if($brand->status == 'active'): echo 'selected'; endif; ?>>Active</option>
                            <option value="inactive" <?php if($brand->status == 'inactive'): echo 'selected'; endif; ?>>Inactive</option>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $attributes = $__attributesOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__attributesOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25)): ?>
<?php $component = $__componentOriginalff6880852fb7a3f71461ce3b06af5a25; ?>
<?php unset($__componentOriginalff6880852fb7a3f71461ce3b06af5a25); ?>
<?php endif; ?>
                    </div>


                </div>
                <div class="text-center pt-15">
                    <?php if (isset($component)) { $__componentOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.button','data' => ['type' => 'submit','class' => 'primary']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'submit','class' => 'primary']); ?>
                        <?php echo e(__('Submit')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9)): ?>
<?php $attributes = $__attributesOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9; ?>
<?php unset($__attributesOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9)): ?>
<?php $component = $__componentOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9; ?>
<?php unset($__componentOriginal3f6fd0a8096e3e9b5a5f3fba28de04b9); ?>
<?php endif; ?>
                </div>
                <!--end::Actions-->
            </form>
            <!--end::Form-->
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $attributes = $__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__attributesOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07)): ?>
<?php $component = $__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07; ?>
<?php unset($__componentOriginal15a72a62debbe72bfa7a4f1dc73a4a07); ?>
<?php endif; ?>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/admin/pages/brands/edit.blade.php ENDPATH**/ ?>