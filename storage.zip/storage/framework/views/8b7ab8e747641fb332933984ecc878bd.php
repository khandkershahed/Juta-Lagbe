<?php if (isset($component)) { $__componentOriginalceadbce536242cd820b2e0a9f88fc791 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalceadbce536242cd820b2e0a9f88fc791 = $attributes; } ?>
<?php $component = App\View\Components\FrontendAppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('frontend-app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\FrontendAppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('Home Page')]); ?>
    <section class="ps-section--banner">
        <div class="ps-section__overlay">
            <div class="ps-section__loading"></div>
        </div>
        <div class="owl-carousel-banner owl-carousel owl-loaded owl-drag" data-owl-auto="false" data-owl-loop="true"
            data-owl-speed="15000" data-owl-gap="0" data-owl-nav="true" data-owl-dots="true" data-owl-item="1"
            data-owl-duration="1000" data-owl-mousedrag="on">
            <div class="owl-stage-outer">
                <div class="owl-stage">
                    <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="owl-item">
                            <div class="ps-banner hero-banner"
                                style="
                            background-image: url('<?php echo e(asset('storage/' . $slider->bg_image)); ?>');
                            background-repeat: no-repeat;
                            background-size: cover;
                            background-position: center center;
                            height: 720px;
                            width: 100%;
                        ">
                                <div class="container container-initial">
                                    <div class="ps-banner__block">
                                        <div class="ps-banner__content">
                                            <h2 class="ps-banner__title text-white"><?php echo e($slider->title); ?></h2>
                                            <div class="ps-banner__desc text-white"><?php echo e($slider->subtitle); ?></div>
                                            <div class="ps-banner__btn-group">
                                                <div class="ps-banner__btn text-white"><?php echo e($slider->badge); ?></div>
                                            </div>
                                            <?php if(!empty($slider->button_link) || !empty($slider->button_name)): ?>
                                                <a class="bg-warning ps-banner__shop" href="<?php echo e($slider->button_link); ?>">
                                                    <?php echo e($slider->button_name); ?>

                                                </a>
                                            <?php endif; ?>
                                            <div class="ps-banner__persen ps-top  fa-bounce"><small>only</small>$25
                                            </div>
                                        </div>
                                        <div class="ps-banner__thumnail">
                                            
                                            
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="owl-nav">

            </div>
        </div>
    </section>
    <div class="ps-home ps-home--14 bg-white">
        <?php if(!empty(optional($special_offer)->slug) || !empty(optional($special_offer)->header_slogan)): ?>
            <div class="ps-noti h-marqee">
                <section>
                    <div class="marquee marquee--hover-pause enable-animation">
                        <div class="marquee__content">
                            <?php for($i = 0; $i < 10; $i++): ?>
                                <a href="<?php echo e(route('special.products', optional($special_offer)->slug)); ?>">
                                    <p class="text-white marquee-text mb-0 d-flex align-items-center">
                                        <span><img class="pr-3 img-fluid" width="60px"
                                                src="<?php echo e(asset('images/markque-icons.png')); ?>" alt=""></span>
                                        <span><?php echo e(optional($special_offer)->header_slogan); ?></span>
                                    </p>
                                </a>
                            <?php endfor; ?>
                        </div>
                        <div aria-hidden="true" class="marquee__content">
                            <?php for($i = 0; $i < 10; $i++): ?>
                                <a href="<?php echo e(route('special.products', optional($special_offer)->slug)); ?>">
                                    <p class="text-white marquee-text mb-0 d-flex align-items-center">
                                        <span><img class="pr-3 img-fluid" width="60px"
                                                src="<?php echo e(asset('images/markque-icons.png')); ?>" alt=""></span>
                                        <span><?php echo e(optional($special_offer)->header_slogan); ?></span>
                                    </p>
                                </a>
                            <?php endfor; ?>
                        </div>
                    </div>
                </section>
            </div>
        <?php endif; ?>
        <?php if($categorys->count() > 0): ?>
            <section class="ps-section--categories" style="background-color: #f3f2f257;">
                <div class="container px-0">
                    <div class="row">
                        <div class="col-lg-8 offset-lg-2">
                            <div class="ps-section__content section-category">
                                <div class="ps-categories__list owl-carousel">
                                    <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="ps-categories__item">
                                            <a class="ps-categories__link"
                                                href="<?php echo e(route('category.products', $category->slug)); ?>">
                                                <?php
                                                    $logoPath = 'storage/' . $category->logo;
                                                    $logoSrc = file_exists(public_path($logoPath))
                                                        ? asset($logoPath)
                                                        : asset('frontend/img/no-category.png');
                                                ?>
                                                <img src="<?php echo e($logoSrc); ?>" alt="<?php echo e($category->name); ?>"
                                                    onerror="this.onerror=null; this.src='frontend/img/no-category.png';">
                                            </a>
                                            <a class="ps-categories__name"
                                                href="<?php echo e(route('category.products', $category->slug)); ?>">
                                                <?php echo e($category->name); ?>

                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>
        <div class="ps-home__content">
            <?php if($latest_products->count() > 0): ?>
                <section class="ps-section--latest-horizontal pt-0">
                    <section class="container px-0">
                        <h3 class="ps-section__title mb-0 py-4" style="font-size: 30px;">Latest Products <img
                                width="40px"
                                src="https://static.vecteezy.com/system/resources/previews/011/999/958/non_2x/fire-icon-free-png.png"
                                alt="" style="position: relative;top: -3px;left: -6px;">
                        </h3>
                        <div class="ps-section__content">
                            <div class="row m-0">
                                <?php $__currentLoopData = $latest_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 col-md-4 col-lg-3 dot4 pr-3 pl-0 mb-3">
                                        <div class="ps-section__product">
                                            <div class="ps-product ps-product--standard">
                                                <div class="ps-product__thumbnail">
                                                    <a class="ps-product__image"
                                                        href="<?php echo e(route('product.details', $latest_product->slug)); ?>">
                                                        <figure>
                                                            <?php if(!empty($latest_product->thumbnail)): ?>
                                                                <?php
                                                                    $thumbnailPath =
                                                                        'storage/' .
                                                                        $latest_product->thumbnail;
                                                                    $thumbnailSrc = file_exists(
                                                                        public_path($thumbnailPath),
                                                                    )
                                                                        ? asset($thumbnailPath)
                                                                        : asset(
                                                                            'frontend/img/no-product.jpg',
                                                                        );
                                                                ?>
                                                                <img src="<?php echo e($thumbnailSrc); ?>"
                                                                    alt="<?php echo e($latest_product->meta_title); ?>"
                                                                    width="210" height="210" />
                                                            <?php else: ?>
                                                                <?php $__currentLoopData = $latest_product->multiImages->slice(0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php
                                                                        $imagePath =
                                                                            'storage/' . $image->photo;
                                                                        $imageSrc = file_exists(
                                                                            public_path($imagePath),
                                                                        )
                                                                            ? asset($imagePath)
                                                                            : asset(
                                                                                'frontend/img/no-product.jpg',
                                                                            );
                                                                    ?>
                                                                    <img src="<?php echo e($imageSrc); ?>"
                                                                        alt="<?php echo e($latest_product->meta_title); ?>"
                                                                        width="210" height="210" />
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </figure>
                                                    </a>
                                                    
                                                    <div class="ps-product__actions">
                                                        <div class="ps-product__item" data-toggle="tooltip"
                                                            data-placement="left" title="Wishlist">
                                                            <a class="add_to_wishlist"
                                                                href="<?php echo e(route('wishlist.store', $latest_product->id)); ?>"><i
                                                                    class="fa fa-heart-o"></i></a>
                                                        </div>
                                                        <div class="ps-product__item" data-toggle="tooltip"
                                                            data-placement="left" title="Quick view">
                                                            <a href="#" data-toggle="modal"
                                                                data-target="#popupQuickview<?php echo e($latest_product->id); ?>">
                                                                <i class="fa fa-eye"></i>
                                                            </a>
                                                        </div>
                                                        <div class="ps-product__item" data-toggle="tooltip"
                                                            data-placement="left" title="Add To Cart">
                                                            <a class="add_to_cart"
                                                                href="<?php echo e(route('cart.store', $latest_product->id)); ?>"
                                                                data-product_id="<?php echo e($latest_product->id); ?>"
                                                                data-product_qty="1">
                                                                <i class="fa fa-shopping-cart"></i>
                                                            </a>
                                                        </div>

                                                    </div>
                                                    <?php if(!empty($latest_product->unit_discount_price)): ?>
                                                        <div class="ps-product__badge">
                                                            <div class="ps-badge ps-badge--sale">
                                                                -
                                                                <?php echo e(!empty($latest_product->unit_discount_price) && $latest_product->unit_discount_price > 0 ? number_format((($latest_product->unit_price - $latest_product->unit_discount_price) / $latest_product->unit_price) * 100, 1) : 0); ?>

                                                                % অফ
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="ps-product__content">
                                                    <h5 class="ps-product__title">
                                                        <a
                                                            href="<?php echo e(route('product.details', $latest_product->slug)); ?>">
                                                            <?php echo e(implode(' ', array_slice(explode(' ', $latest_product->name), 0, 5))); ?>

                                                        </a>
                                                    </h5>
                                                    <div class="pb-3">
                                                        <?php if(!empty($latest_product->unit_discount_price)): ?>
                                                            <div class="ps-product__meta">
                                                                <span
                                                                    class="ps-product__price sale"><?php echo e($latest_product->unit_discount_price); ?>

                                                                    টাকা</span>
                                                                <span
                                                                    class="ps-product__del text-danger"><?php echo e($latest_product->unit_price); ?>

                                                                    টাকা</span>
                                                            </div>
                                                        <?php else: ?>
                                                            <div class="ps-product__meta">
                                                                <span
                                                                    class="ps-product__price sale"><?php echo e($latest_product->unit_price); ?>

                                                                    টাকা</span>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="d-flex align-items-center card-cart-btn">
                                                        <a href="<?php echo e(route('buy.now', $latest_product->id)); ?>"
                                                            class="btn btn-primary rounded-0 w-100">
                                                            <i class="fa-solid fa-basket-shopping pr-2"></i>
                                                            অর্ডার
                                                            করুন
                                                        </a>
                                                    </div>
                                                    <div
                                                        class="ps-product__actions ps-product__group-mobile">
                                                        <div class="ps-product__quantity">
                                                            <div
                                                                class="def-number-input number-input safari_only">
                                                                <button class="minus"
                                                                    onclick="this.parentNode.querySelector('input[type=number]').stepDown()"><i
                                                                        class="icon-minus"></i>
                                                                </button>
                                                                <input class="quantity" min="0"
                                                                    name="quantity" value="1"
                                                                    type="number" />
                                                                <button class="plus"
                                                                    onclick="this.parentNode.querySelector('input[type=number]').stepUp()"><i
                                                                        class="icon-plus"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                        <div class="ps-product__item"
                                                            data-toggle="tooltip" data-placement="left"
                                                            title="Wishlist"><a class="add_to_wishlist"
                                                                href="<?php echo e(route('wishlist.store', $latest_product->id)); ?>"><i
                                                                    class="fa fa-heart-o"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </section>
                </section>
            <?php endif; ?>
            <section class="mb-5">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-4 pl-0">
                            <div class="row banner-first-row">
                                <div class="col-lg-12 mb-4">
                                    <div class="image-container">
                                        <a href="">
                                            <img class="img-fluid" src="<?php echo e(asset('images/home-banner-side-one.png')); ?>" alt="">
                                            <span class="overlay-text">Your Text Here</span> <!-- Text that appears on hover -->
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="image-container">
                                        <a href="">
                                            <img class="img-fluid" src="<?php echo e(asset('images/home-banner-side-two.png')); ?>" alt="">
                                            <span class="overlay-text">Your Text Here</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 px-2">
                            <div class="image-container">
                                <a href="" class="section-banner-main">
                                    <img class="img-fluid" src="<?php echo e(asset('images/home-banner-side-center.png')); ?>" alt="">
                                    <span class="overlay-text">Your Text Here</span>
                                </a>
                            </div>
                        </div>
                        <div class="col-lg-4 pr-3 pr-lg-0">
                            <div class="row">
                                <div class="col-lg-12 mb-4">
                                    <div class="image-container">
                                        <a href="">
                                            <img class="img-fluid" src="<?php echo e(asset('images/home-banner-side-three.png')); ?>" alt="">
                                            <span class="overlay-text">Your Text Here</span>
                                        </a>
                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="image-container">
                                        <a href="">
                                            <img class="img-fluid" src="<?php echo e(asset('images/home-banner-side-four.png')); ?>" alt="">
                                            <span class="overlay-text">Your Text Here</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>


            <?php if($categoryone && $categoryoneproducts->count() > 0): ?>
                <div class="container px-0">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="d-flex justify-content-between align-items-center pb-4 pb-lg-5">
                                <div class="">
                                    <h3 class="ps-section__title mb-0" style="font-size: 30px;">
                                        <?php echo e(optional($categoryone)->name); ?></h3>
                                </div>
                                <div style="width: 100%" class="px-3">
                                    <span style="height: 1px; background-color:#c9c8c8; display: block"></span>
                                </div>
                                <div class="ps-delivery ps-delivery--info p-0">
                                    <a class="ps-delivery__more" href="http://127.0.0.1:8000/shop">আরো দেখুন <i class="fa-solid fa-"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="ps-home--block">
                        <div class="ps-section__content">
                            <div class="row m-0">
                                <?php $__currentLoopData = $categoryoneproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoryoneproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 col-md-4 col-lg-3 dot4 pr-3 pl-0">
                                        <div class="ps-section__product border">
                                            <div class="ps-product ps-product--standard">
                                                <div class="ps-product__thumbnail">
                                                    <a class="ps-product__image"
                                                        href="<?php echo e(route('product.details', $categoryoneproduct->slug)); ?>">
                                                        <figure>
                                                            <?php if(!empty($categoryoneproduct->thumbnail)): ?>
                                                                <?php
                                                                    $thumbnailPath =
                                                                        'storage/' .
                                                                        $categoryoneproduct->thumbnail;
                                                                    $thumbnailSrc = file_exists(
                                                                        public_path($thumbnailPath),
                                                                    )
                                                                        ? asset($thumbnailPath)
                                                                        : asset(
                                                                            'frontend/img/no-product.jpg',
                                                                        );
                                                                ?>
                                                                <img src="<?php echo e($thumbnailSrc); ?>"
                                                                    alt="<?php echo e($categoryoneproduct->meta_title); ?>"
                                                                    width="210" height="210" />
                                                            <?php else: ?>
                                                                <?php $__currentLoopData = $categoryoneproduct->multiImages->slice(0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php
                                                                        $imagePath =
                                                                            'storage/' . $image->photo;
                                                                        $imageSrc = file_exists(
                                                                            public_path($imagePath),
                                                                        )
                                                                            ? asset($imagePath)
                                                                            : asset(
                                                                                'frontend/img/no-product.jpg',
                                                                            );
                                                                    ?>
                                                                    <img src="<?php echo e($imageSrc); ?>"
                                                                        alt="<?php echo e($categoryoneproduct->meta_title); ?>"
                                                                        width="210" height="210" />
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </figure>
                                                    </a>
                                                    
                                                    <div class="ps-product__actions">
                                                        <div class="ps-product__item" data-toggle="tooltip"
                                                            data-placement="left" title="Wishlist">
                                                            <a class="add_to_wishlist"
                                                                href="<?php echo e(route('wishlist.store', $categoryoneproduct->id)); ?>"><i
                                                                    class="fa fa-heart-o"></i></a>
                                                        </div>
                                                        <div class="ps-product__item" data-toggle="tooltip"
                                                            data-placement="left" title="Quick view">
                                                            <a href="#" data-toggle="modal"
                                                                data-target="#popupQuickview<?php echo e($categoryoneproduct->id); ?>">
                                                                <i class="fa fa-eye"></i>
                                                            </a>
                                                        </div>
                                                        <div class="ps-product__item" data-toggle="tooltip"
                                                            data-placement="left" title="Add To Cart">
                                                            <a class="add_to_cart"
                                                                href="<?php echo e(route('cart.store', $categoryoneproduct->id)); ?>"
                                                                data-product_id="<?php echo e($categoryoneproduct->id); ?>"
                                                                data-product_qty="1">
                                                                <i class="fa fa-shopping-cart"></i>
                                                            </a>
                                                        </div>

                                                    </div>
                                                    <?php if(!empty($categoryoneproduct->unit_discount_price)): ?>
                                                        <div class="ps-product__badge">
                                                            <div class="ps-badge ps-badge--sale">
                                                                -
                                                                <?php echo e(!empty($categoryoneproduct->unit_discount_price) && $categoryoneproduct->unit_discount_price > 0 ? number_format((($categoryoneproduct->unit_price - $categoryoneproduct->unit_discount_price) / $categoryoneproduct->unit_price) * 100, 1) : 0); ?>

                                                                % অফ
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="ps-product__content">
                                                    <h5 class="ps-product__title">
                                                        <a
                                                            href="<?php echo e(route('product.details', $categoryoneproduct->slug)); ?>">
                                                            <?php echo e(implode(' ', array_slice(explode(' ', $categoryoneproduct->name), 0, 5))); ?>

                                                        </a>
                                                    </h5>
                                                    <div class="pb-3">
                                                        <?php if(!empty($categoryoneproduct->unit_discount_price)): ?>
                                                            <div class="ps-product__meta">
                                                                <span
                                                                    class="ps-product__price sale"><?php echo e($categoryoneproduct->unit_discount_price); ?>

                                                                    টাকা</span>
                                                                <span
                                                                    class="ps-product__del text-danger"><?php echo e($categoryoneproduct->unit_price); ?>

                                                                    টাকা</span>
                                                            </div>
                                                        <?php else: ?>
                                                            <div class="ps-product__meta">
                                                                <span
                                                                    class="ps-product__price sale"><?php echo e($categoryoneproduct->unit_price); ?>

                                                                    টাকা</span>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="d-flex align-items-center card-cart-btn">
                                                        <a href="<?php echo e(route('buy.now', $categoryoneproduct->id)); ?>"
                                                            class="btn btn-primary rounded-0 w-100">
                                                            <i class="fa-solid fa-basket-shopping pr-2"></i>
                                                            অর্ডার
                                                            করুন
                                                        </a>
                                                    </div>
                                                    <div
                                                        class="ps-product__actions ps-product__group-mobile">
                                                        <div class="ps-product__quantity">
                                                            <div
                                                                class="def-number-input number-input safari_only">
                                                                <button class="minus"
                                                                    onclick="this.parentNode.querySelector('input[type=number]').stepDown()"><i
                                                                        class="icon-minus"></i>
                                                                </button>
                                                                <input class="quantity" min="0"
                                                                    name="quantity" value="1"
                                                                    type="number" />
                                                                <button class="plus"
                                                                    onclick="this.parentNode.querySelector('input[type=number]').stepUp()"><i
                                                                        class="icon-plus"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                        <div class="ps-product__item"
                                                            data-toggle="tooltip" data-placement="left"
                                                            title="Wishlist"><a class="add_to_wishlist"
                                                                href="<?php echo e(route('wishlist.store', $categoryoneproduct->id)); ?>"><i
                                                                    class="fa fa-heart-o"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <div class="container-fluid" style="background-image: linear-gradient(to right, #051937, #004d7a, #008793, #00bf72, #a8eb12);">
                <div class="container juta-delivery">
                    <div class="row align-items-center">
                        <div class="col-lg-8">
                            <div class="ps-delivery ps-delivery--info">
                                <div class="ps-delivery__content">
                                    <div class="ps-delivery__text text-white">
                                        <i class="icon-shield-check"></i>
                                        <span>
                                            <strong>100% Secure Delivery</strong> Without Courier Communication.
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <div class="delivery-icons">
                                <img class="img-fluid" src="<?php echo e(asset('images/delivery-icons.png')); ?>"
                                    alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php if($categorytwo && $categorytwoproducts->count() > 0): ?>
                <section class="ps-section--latest mt-0">
                    <div class="container px-0">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="d-flex justify-content-between align-items-center py-4 pt-0 py-lg-5">
                                    <div class="">
                                        <h3 class="ps-section__title mb-0" style="font-size: 30px;">
                                            <?php echo e(optional($categorytwo)->name); ?></h3>
                                    </div>
                                    <div style="width: 100%" class="px-3">
                                        <span style="height: 1px; background-color:#c9c8c8; display: block"></span>
                                    </div>
                                    <div class="ps-delivery ps-delivery--info p-0">
                                        <a class="ps-delivery__more" href="http://127.0.0.1:8000/shop">আরো দেখুন <i class="fa-solid fa-"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="ps-section__carousel mb-0">
                            <div class="takeway-slider owl-carousel owl-loaded owl-drag">
                                <div class="owl-stage-outer">
                                    <div class="owl-stage"
                                        style="transform: translate3d(-2228px, 0px, 0px); transition: 1s; width: 4952px;">
                                        <?php $__currentLoopData = $categorytwoproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorytwoproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="owl-item" style="width: 247.6px;">
                                                <div class="ps-section__product border">
                                                    <div class="ps-product ps-product--standard">
                                                        <div class="ps-product__thumbnail">
                                                            <a class="ps-product__image"
                                                                href="<?php echo e(route('product.details', $categorytwoproduct->slug)); ?>">
                                                                <figure>
                                                                    <?php if(!empty($categorytwoproduct->thumbnail)): ?>
                                                                        <?php
                                                                            $thumbnailPath =
                                                                                'storage/' .
                                                                                $categorytwoproduct->thumbnail;
                                                                            $thumbnailSrc = file_exists(
                                                                                public_path($thumbnailPath),
                                                                            )
                                                                                ? asset($thumbnailPath)
                                                                                : asset(
                                                                                    'frontend/img/no-product.jpg',
                                                                                );
                                                                        ?>
                                                                        <img src="<?php echo e($thumbnailSrc); ?>"
                                                                            alt="<?php echo e($categorytwoproduct->meta_title); ?>"
                                                                            width="210" height="210" />
                                                                    <?php else: ?>
                                                                        <?php $__currentLoopData = $categorytwoproduct->multiImages->slice(0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php
                                                                                $imagePath =
                                                                                    'storage/' . $image->photo;
                                                                                $imageSrc = file_exists(
                                                                                    public_path($imagePath),
                                                                                )
                                                                                    ? asset($imagePath)
                                                                                    : asset(
                                                                                        'frontend/img/no-product.jpg',
                                                                                    );
                                                                            ?>
                                                                            <img src="<?php echo e($imageSrc); ?>"
                                                                                alt="<?php echo e($categorytwoproduct->meta_title); ?>"
                                                                                width="210" height="210" />
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php endif; ?>
                                                                </figure>
                                                            </a>
                                                            
                                                            <?php if(count($categorytwoproduct->reviews) > 0): ?>
                                                                <div>
                                                                    <?php
                                                                        $review =
                                                                            count($categorytwoproduct->reviews) > 0
                                                                                ? optional(
                                                                                        $categorytwoproduct->reviews,
                                                                                    )->sum('rating') /
                                                                                    count(
                                                                                        $categorytwoproduct->reviews,
                                                                                    )
                                                                                : 0;
                                                                    ?>
                                                                    <div
                                                                        class="d-flex justify-content-between align-items-center my-2 rating-area px-3">
                                                                        <div style="color: var(--site-primary)">
                                                                            Reviews
                                                                            (<?php echo e(count($categorytwoproduct->reviews)); ?>)
                                                                        </div>
                                                                        <div class="ps-product__rating">
                                                                            <?php if($review > 0): ?>
                                                                                <div
                                                                                    class="br-wrapper br-theme-fontawesome-stars">
                                                                                    <select class="ps-rating"
                                                                                        data-read-only="true"
                                                                                        style="display: none;">
                                                                                        <?php
                                                                                            $maxRating = min(
                                                                                                5,
                                                                                                max(
                                                                                                    1,
                                                                                                    floor($review),
                                                                                                ),
                                                                                            ); // Get the highest full rating value
                                                                                        ?>
                                                                                        <?php for($i = 1; $i <= $maxRating; $i++): ?>
                                                                                            <option
                                                                                                value="<?php echo e($i); ?>">
                                                                                                <?php echo e($i); ?>

                                                                                            </option>
                                                                                        <?php endfor; ?>
                                                                                    </select>
                                                                                </div>
                                                                            <?php else: ?>
                                                                                <span class="no-found">N/A</span>
                                                                            <?php endif; ?>
                                                                        </div>
                                                                    </div>
                                                                    <hr class="my-0">
                                                                </div>
                                                            <?php endif; ?>

                                                            
                                                            <div class="ps-product__actions">
                                                                <div class="ps-product__item" data-toggle="tooltip"
                                                                    data-placement="left" title="Wishlist">
                                                                    <a class="add_to_wishlist"
                                                                        href="<?php echo e(route('wishlist.store', $categorytwoproduct->id)); ?>"><i
                                                                            class="fa fa-heart-o"></i></a>
                                                                </div>
                                                                <div class="ps-product__item" data-toggle="tooltip"
                                                                    data-placement="left" title="Quick view">
                                                                    <a href="#" data-toggle="modal"
                                                                        data-target="#popupQuickview<?php echo e($categorytwoproduct->id); ?>">
                                                                        <i class="fa fa-eye"></i>
                                                                    </a>
                                                                </div>
                                                                <div class="ps-product__item" data-toggle="tooltip"
                                                                    data-placement="left" title="Add To Cart">
                                                                    <a class="add_to_cart"
                                                                        href="<?php echo e(route('cart.store', $categorytwoproduct->id)); ?>"
                                                                        data-product_id="<?php echo e($categorytwoproduct->id); ?>"
                                                                        data-product_qty="1">
                                                                        <i class="fa fa-shopping-cart"></i>
                                                                    </a>
                                                                </div>

                                                            </div>
                                                            <?php if(!empty($categorytwoproduct->unit_discount_price)): ?>
                                                                <div class="ps-product__badge">
                                                                    <div class="ps-badge ps-badge--sale">
                                                                        -
                                                                        <?php echo e(!empty($categorytwoproduct->unit_discount_price) && $categorytwoproduct->unit_discount_price > 0 ? number_format((($categorytwoproduct->unit_price - $categorytwoproduct->unit_discount_price) / $categorytwoproduct->unit_price) * 100, 1) : 0); ?>

                                                                        % অফ
                                                                    </div>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                        <div class="ps-product__content">
                                                            <h5 class="ps-product__title">
                                                                <a
                                                                    href="<?php echo e(route('product.details', $categorytwoproduct->slug)); ?>">
                                                                    <?php echo e(implode(' ', array_slice(explode(' ', $categorytwoproduct->name), 0, 5))); ?>

                                                                </a>
                                                            </h5>
                                                            <div class="pb-3">
                                                                <?php if(!empty($categorytwoproduct->unit_discount_price)): ?>
                                                                    <div class="ps-product__meta">
                                                                        <span
                                                                            class="ps-product__price sale"><?php echo e($categorytwoproduct->unit_discount_price); ?>

                                                                            টাকা</span>
                                                                        <span
                                                                            class="ps-product__del text-danger"><?php echo e($categorytwoproduct->unit_price); ?>

                                                                            টাকা</span>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <div class="ps-product__meta">
                                                                        <span
                                                                            class="ps-product__price sale"><?php echo e($categorytwoproduct->unit_price); ?>

                                                                            টাকা</span>
                                                                    </div>
                                                                <?php endif; ?>
                                                            </div>
                                                            <div class="d-flex align-items-center card-cart-btn">
                                                                <a href="<?php echo e(route('buy.now', $categorytwoproduct->id)); ?>"
                                                                    class="btn btn-primary rounded-0 w-100">
                                                                    <i class="fa-solid fa-basket-shopping pr-2"></i>
                                                                    অর্ডার
                                                                    করুন
                                                                </a>
                                                            </div>
                                                            <div
                                                                class="ps-product__actions ps-product__group-mobile">
                                                                <div class="ps-product__quantity">
                                                                    <div
                                                                        class="def-number-input number-input safari_only">
                                                                        <button class="minus"
                                                                            onclick="this.parentNode.querySelector('input[type=number]').stepDown()"><i
                                                                                class="icon-minus"></i>
                                                                        </button>
                                                                        <input class="quantity" min="0"
                                                                            name="quantity" value="1"
                                                                            type="number" />
                                                                        <button class="plus"
                                                                            onclick="this.parentNode.querySelector('input[type=number]').stepUp()"><i
                                                                                class="icon-plus"></i>
                                                                        </button>
                                                                    </div>
                                                                </div>
                                                                <div class="ps-product__item"
                                                                    data-toggle="tooltip" data-placement="left"
                                                                    title="Wishlist"><a class="add_to_wishlist"
                                                                        href="<?php echo e(route('wishlist.store', $categorytwoproduct->id)); ?>"><i
                                                                            class="fa fa-heart-o"></i></a>
                                                                </div>

                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            <?php endif; ?>
            <?php if($categorythree && $categorythreeproducts->count() > 0): ?>
                <div class="container px-0 mb-5 pb-0 pb-lg-5">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="d-flex justify-content-between align-items-center py-4 py-lg-5">
                                <div class="">
                                    <h3 class="ps-section__title mb-0" style="font-size: 30px;">
                                        <?php echo e(optional($categorythree)->name); ?></h3>
                                </div>
                                <div style="width: 100%" class="px-3">
                                    <span style="height: 1px; background-color:#c9c8c8; display: block"></span>
                                </div>
                                <div class="ps-delivery ps-delivery--info p-0">
                                    <a class="ps-delivery__more" href="http://127.0.0.1:8000/shop">আরো দেখুন <i class="fa-solid fa-"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="ps-home--block">
                        <div class="ps-section__content">
                            <div class="row m-0">
                                <?php $__currentLoopData = $categorythreeproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categorythreeproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-6 col-md-4 col-lg-3 dot4 pr-3 pl-0">
                                        <div class="ps-section__product border">
                                            <div class="ps-product ps-product--standard">
                                                <div class="ps-product__thumbnail">
                                                    <a class="ps-product__image"
                                                        href="<?php echo e(route('product.details', $categorythreeproduct->slug)); ?>">
                                                        <figure>
                                                            <?php if(!empty($categorythreeproduct->thumbnail)): ?>
                                                                <?php
                                                                    $thumbnailPath =
                                                                        'storage/' .
                                                                        $categorythreeproduct->thumbnail;
                                                                    $thumbnailSrc = file_exists(
                                                                        public_path($thumbnailPath),
                                                                    )
                                                                        ? asset($thumbnailPath)
                                                                        : asset(
                                                                            'frontend/img/no-product.jpg',
                                                                        );
                                                                ?>
                                                                <img src="<?php echo e($thumbnailSrc); ?>"
                                                                    alt="<?php echo e($categorythreeproduct->meta_title); ?>"
                                                                    width="210" height="210" />
                                                            <?php else: ?>
                                                                <?php $__currentLoopData = $categorythreeproduct->multiImages->slice(0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php
                                                                        $imagePath =
                                                                            'storage/' . $image->photo;
                                                                        $imageSrc = file_exists(
                                                                            public_path($imagePath),
                                                                        )
                                                                            ? asset($imagePath)
                                                                            : asset(
                                                                                'frontend/img/no-product.jpg',
                                                                            );
                                                                    ?>
                                                                    <img src="<?php echo e($imageSrc); ?>"
                                                                        alt="<?php echo e($categorythreeproduct->meta_title); ?>"
                                                                        width="210" height="210" />
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endif; ?>
                                                        </figure>
                                                    </a>
                                                    
                                                    <div class="ps-product__actions">
                                                        <div class="ps-product__item" data-toggle="tooltip"
                                                            data-placement="left" title="Wishlist">
                                                            <a class="add_to_wishlist"
                                                                href="<?php echo e(route('wishlist.store', $categorythreeproduct->id)); ?>"><i
                                                                    class="fa fa-heart-o"></i></a>
                                                        </div>
                                                        <div class="ps-product__item" data-toggle="tooltip"
                                                            data-placement="left" title="Quick view">
                                                            <a href="#" data-toggle="modal"
                                                                data-target="#popupQuickview<?php echo e($categorythreeproduct->id); ?>">
                                                                <i class="fa fa-eye"></i>
                                                            </a>
                                                        </div>
                                                        <div class="ps-product__item" data-toggle="tooltip"
                                                            data-placement="left" title="Add To Cart">
                                                            <a class="add_to_cart"
                                                                href="<?php echo e(route('cart.store', $categorythreeproduct->id)); ?>"
                                                                data-product_id="<?php echo e($categorythreeproduct->id); ?>"
                                                                data-product_qty="1">
                                                                <i class="fa fa-shopping-cart"></i>
                                                            </a>
                                                        </div>

                                                    </div>
                                                    <?php if(!empty($categorythreeproduct->unit_discount_price)): ?>
                                                        <div class="ps-product__badge">
                                                            <div class="ps-badge ps-badge--sale">
                                                                -
                                                                <?php echo e(!empty($categorythreeproduct->unit_discount_price) && $categorythreeproduct->unit_discount_price > 0 ? number_format((($categorythreeproduct->unit_price - $categorythreeproduct->unit_discount_price) / $categorythreeproduct->unit_price) * 100, 1) : 0); ?>

                                                                % অফ
                                                            </div>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="ps-product__content">
                                                    <h5 class="ps-product__title">
                                                        <a
                                                            href="<?php echo e(route('product.details', $categorythreeproduct->slug)); ?>">
                                                            <?php echo e(implode(' ', array_slice(explode(' ', $categorythreeproduct->name), 0, 5))); ?>

                                                        </a>
                                                    </h5>
                                                    <div class="pb-3">
                                                        <?php if(!empty($categorythreeproduct->unit_discount_price)): ?>
                                                            <div class="ps-product__meta">
                                                                <span
                                                                    class="ps-product__price sale"><?php echo e($categorythreeproduct->unit_discount_price); ?>

                                                                    টাকা</span>
                                                                <span
                                                                    class="ps-product__del text-danger"><?php echo e($categorythreeproduct->unit_price); ?>

                                                                    টাকা</span>
                                                            </div>
                                                        <?php else: ?>
                                                            <div class="ps-product__meta">
                                                                <span
                                                                    class="ps-product__price sale"><?php echo e($categorythreeproduct->unit_price); ?>

                                                                    টাকা</span>
                                                            </div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="d-flex align-items-center card-cart-btn">
                                                        <a href="<?php echo e(route('buy.now', $categorythreeproduct->id)); ?>"
                                                            class="btn btn-primary rounded-0 w-100">
                                                            <i class="fa-solid fa-basket-shopping pr-2"></i>
                                                            অর্ডার
                                                            করুন
                                                        </a>
                                                    </div>
                                                    <div
                                                        class="ps-product__actions ps-product__group-mobile">
                                                        <div class="ps-product__quantity">
                                                            <div
                                                                class="def-number-input number-input safari_only">
                                                                <button class="minus"
                                                                    onclick="this.parentNode.querySelector('input[type=number]').stepDown()"><i
                                                                        class="icon-minus"></i>
                                                                </button>
                                                                <input class="quantity" min="0"
                                                                    name="quantity" value="1"
                                                                    type="number" />
                                                                <button class="plus"
                                                                    onclick="this.parentNode.querySelector('input[type=number]').stepUp()"><i
                                                                        class="icon-plus"></i>
                                                                </button>
                                                            </div>
                                                        </div>
                                                        <div class="ps-product__item"
                                                            data-toggle="tooltip" data-placement="left"
                                                            title="Wishlist"><a class="add_to_wishlist"
                                                                href="<?php echo e(route('wishlist.store', $categorythreeproduct->id)); ?>"><i
                                                                    class="fa fa-heart-o"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php if($deals->count() > 0 || $deal_products->count() > 0): ?>
            <div class="container px-0">
                <?php if($deals->count() > 0): ?>
                    <h3 class="ps-section__title pb-3 pb-lg-5 mb-0" style="font-size: 30px;">This week deals</h3>
                    <div class="ps-promo ps-promo--home">
                        <!-- First Row: First Three Deals -->
                        <div class="row">
                            <?php $__currentLoopData = $deals->slice(0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-6 col-md-4">
                                    <div class="ps-promo__item">
                                        <a href="<?php echo e(route('product.details', $deal->product->slug)); ?>">
                                            <?php if($deal->image): ?>
                                                <img class="ps-promo__banner"
                                                    src="<?php echo e(!empty($deal->image) && file_exists(public_path('storage/' . $deal->image)) ? asset('storage/' . $deal->image) : asset('images/no_image.png')); ?>"
                                                    alt="alt" />
                                            <?php endif; ?>
                                            <div class="ps-promo__content">
                                                <?php if($deal->badge): ?>
                                                    <span class="ps-promo__badge">
                                                        <?php echo e($deal->badge ?? round(100 - ($deal->offer_price / $deal->price) * 100) . '%'); ?>

                                                    </span>
                                                <?php endif; ?>
                                                <h4 class="text-white ps-promo__name">
                                                    <?php echo e($deal->title); ?>

                                                </h4>
                                                <?php if($deal->subtitle): ?>
                                                    <p><?php echo e($deal->subtitle); ?></p>
                                                <?php endif; ?>
                                                <?php if($deal->offer_price && $deal->price): ?>
                                                    <div class="ps-promo__meta">
                                                        <p class="ps-promo__price text-warning">
                                                            ৳<?php echo e($deal->offer_price); ?>

                                                        </p>
                                                        <p class="ps-promo__del text-white">৳<?php echo e($deal->price); ?>

                                                        </p>
                                                    </div>
                                                <?php endif; ?>
                                                <?php if(!empty($deal->button_link)): ?>
                                                    <a class="btn-green ps-promo__btn"
                                                        href="<?php echo e($deal->button_link); ?>"><?php echo e($deal->button_name); ?></a>
                                                <?php elseif(!empty($deal->product_id)): ?>
                                                    <a class="btn-green ps-promo__btn"
                                                        href="<?php echo e(route('product.details', $deal->product->slug)); ?>">Buy
                                                        now</a>
                                                <?php endif; ?>
                                            </div>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <!-- Second Row: Next Four Deals -->
                        <div class="row ps-promo--horizontal">
                            <?php $__currentLoopData = $deals->slice(3, 4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-12 col-md-3">
                                    <div class="ps-promo__item">
                                        <?php if($deal->image): ?>
                                            <img class="ps-promo__banner"
                                                src="<?php echo e(asset('storage/' . $deal->image)); ?>" alt="alt" />
                                        <?php endif; ?>
                                        <div class="ps-promo__content">
                                            <h4 class="text-dark ps-promo__name">
                                                <?php echo e($deal->title); ?>

                                            </h4>
                                            <?php if($deal->offer_price && $deal->price): ?>
                                                <div class="ps-promo__meta">
                                                    <p class="ps-promo__price text-warning">
                                                        ৳ <?php echo e(number_format($deal->offer_price, 2)); ?></p>
                                                    <p class="ps-promo__del text-dark">
                                                        ৳ <?php echo e(number_format($deal->price, 2)); ?></p>
                                                </div>
                                            <?php endif; ?>
                                            <?php if(!empty($deal->button_link)): ?>
                                                <a class="btn-green ps-promo__btn"
                                                    href="<?php echo e($deal->button_link); ?>"><?php echo e($deal->button_name); ?></a>
                                            <?php elseif(!empty($deal->product_id)): ?>
                                                <a class="btn-green ps-promo__btn"
                                                    href="<?php echo e(route('product.details', $deal->product->slug)); ?>">Buy
                                                    now</a>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if($deal_products->count() > 0): ?>
                    <section class="ps-section--deals">
                        <div class="ps-section__header">
                            <h3 class="ps-section__title  mb-0" style="font-size: 30px;">Best Deals of the
                                week!</h3>
                        </div>
                        <div class="ps-section__carousel">
                            <div class="dealCarousel owl-carousel">
                                <?php $__currentLoopData = $deal_products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $deal_product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="ps-section__product border">
                                        <div class="ps-product ps-product--standard">
                                            <div class="ps-product__thumbnail">
                                                <a class="ps-product__image"
                                                    href="<?php echo e(route('product.details', $deal_product->slug)); ?>">
                                                    <figure>
                                                        <?php if(!empty($deal_product->thumbnail)): ?>
                                                            <?php
                                                                $thumbnailPath =
                                                                    'storage/' .
                                                                    $deal_product->thumbnail;
                                                                $thumbnailSrc = file_exists(
                                                                    public_path($thumbnailPath),
                                                                )
                                                                    ? asset($thumbnailPath)
                                                                    : asset(
                                                                        'frontend/img/no-product.jpg',
                                                                    );
                                                            ?>
                                                            <img src="<?php echo e($thumbnailSrc); ?>"
                                                                alt="<?php echo e($deal_product->meta_title); ?>"
                                                                width="210" height="210" />
                                                        <?php else: ?>
                                                            <?php $__currentLoopData = $deal_product->multiImages->slice(0, 2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php
                                                                    $imagePath =
                                                                        'storage/' . $image->photo;
                                                                    $imageSrc = file_exists(
                                                                        public_path($imagePath),
                                                                    )
                                                                        ? asset($imagePath)
                                                                        : asset(
                                                                            'frontend/img/no-product.jpg',
                                                                        );
                                                                ?>
                                                                <img src="<?php echo e($imageSrc); ?>"
                                                                    alt="<?php echo e($deal_product->meta_title); ?>"
                                                                    width="210" height="210" />
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php endif; ?>
                                                    </figure>
                                                </a>

                                                
                                                <div class="ps-product__actions">
                                                    <div class="ps-product__item" data-toggle="tooltip"
                                                        data-placement="left" title="Wishlist">
                                                        <a class="add_to_wishlist"
                                                            href="<?php echo e(route('wishlist.store', $deal_product->id)); ?>"><i
                                                                class="fa fa-heart-o"></i></a>
                                                    </div>
                                                    <div class="ps-product__item" data-toggle="tooltip"
                                                        data-placement="left" title="Quick view">
                                                        <a href="#" data-toggle="modal"
                                                            data-target="#popupQuickview<?php echo e($deal_product->id); ?>">
                                                            <i class="fa fa-eye"></i>
                                                        </a>
                                                    </div>
                                                    <div class="ps-product__item" data-toggle="tooltip"
                                                        data-placement="left" title="Add To Cart">
                                                        <a class="add_to_cart"
                                                            href="<?php echo e(route('cart.store', $deal_product->id)); ?>"
                                                            data-product_id="<?php echo e($deal_product->id); ?>"
                                                            data-product_qty="1">
                                                            <i class="fa fa-shopping-cart"></i>
                                                        </a>
                                                    </div>

                                                </div>
                                                <?php if(!empty($deal_product->unit_discount_price)): ?>
                                                    <div class="ps-product__badge">
                                                        <div class="ps-badge ps-badge--sale">
                                                            -
                                                            <?php echo e(!empty($deal_product->unit_discount_price) && $deal_product->unit_discount_price > 0 ? number_format((($deal_product->unit_price - $deal_product->unit_discount_price) / $deal_product->unit_price) * 100, 1) : 0); ?>

                                                            % অফ
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            </div>
                                            <div class="ps-product__content">
                                                <h5 class="ps-product__title">
                                                    <a
                                                        href="<?php echo e(route('product.details', $deal_product->slug)); ?>">
                                                        <?php echo e(implode(' ', array_slice(explode(' ', $deal_product->name), 0, 5))); ?>

                                                    </a>
                                                </h5>
                                                <div class="pb-3">
                                                    <?php if(!empty($deal_product->unit_discount_price)): ?>
                                                        <div class="ps-product__meta">
                                                            <span
                                                                class="ps-product__price sale"><?php echo e($deal_product->unit_discount_price); ?>

                                                                টাকা</span>
                                                            <span
                                                                class="ps-product__del text-danger"><?php echo e($deal_product->unit_price); ?>

                                                                টাকা</span>
                                                        </div>
                                                    <?php else: ?>
                                                        <div class="ps-product__meta">
                                                            <span
                                                                class="ps-product__price sale"><?php echo e($deal_product->unit_price); ?>

                                                                টাকা</span>
                                                        </div>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="d-flex align-items-center card-cart-btn">
                                                    <a href="<?php echo e(route('buy.now', $deal_product->id)); ?>"
                                                        class="btn btn-primary rounded-0 w-100">
                                                        <i class="fa-solid fa-basket-shopping pr-2"></i>
                                                        অর্ডার
                                                        করুন
                                                    </a>
                                                </div>
                                                <div
                                                    class="ps-product__actions ps-product__group-mobile">
                                                    <div class="ps-product__quantity">
                                                        <div
                                                            class="def-number-input number-input safari_only">
                                                            <button class="minus"
                                                                onclick="this.parentNode.querySelector('input[type=number]').stepDown()"><i
                                                                    class="icon-minus"></i>
                                                            </button>
                                                            <input class="quantity" min="0"
                                                                name="quantity" value="1"
                                                                type="number" />
                                                            <button class="plus"
                                                                onclick="this.parentNode.querySelector('input[type=number]').stepUp()"><i
                                                                    class="icon-plus"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <div class="ps-product__item"
                                                        data-toggle="tooltip" data-placement="left"
                                                        title="Wishlist"><a class="add_to_wishlist"
                                                            href="<?php echo e(route('wishlist.store', $deal_product->id)); ?>"><i
                                                                class="fa fa-heart-o"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </section>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php echo $__env->make('frontend.layouts.HomeQuickViewModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php $__env->startPush('scripts'); ?>
        <script>
            $(document).ready(function() {
                $('.dealCarousel').owlCarousel({
                    loop: true,
                    margin: 10,
                    nav: true,
                    dots: true,
                    autoplay: false,
                    autoplayTimeout: 5000,
                    autoplayHoverPause: true,
                    navText: [
                        '<div class="dealCarousel-prev">←</div>',
                        '<div class="dealCarousel-next">→</div>'
                    ],
                    responsive: {
                        0: {
                            items: 1
                        },
                        600: {
                            items: 2
                        },
                        1000: {
                            items: 4
                        }
                    }
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $(".blog-slider").owlCarousel({
                    loop: true, // Enable continuous loop mode
                    margin: 10, // Space between items
                    nav: true, // Show next/prev buttons
                    items: 3,
                    dots: true, // Show dots for navigation
                    autoplay: true, // Enable autoplay
                    autoplayTimeout: 3000, // Delay for autoplay
                    responsive: {
                        0: {
                            items: 1, // 1 item at a time for small screens
                        },
                        600: {
                            items: 2, // 2 items at a time for medium screens
                        },
                        1000: {
                            items: 3, // 3 items at a time for large screens
                        },
                    },
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $(".takeway-slider").owlCarousel({
                    loop: true, // Enable continuous loop mode
                    margin: 10, // Space between items
                    nav: true, // Show next/prev buttons
                    items: 4,
                    dots: true, // Show dots for navigation
                    autoplay: true, // Enable autoplay
                    autoplayTimeout: 3000, // Delay for autoplay
                    responsive: {
                        0: {
                            items: 2, // 1 item at a time for small screens
                        },
                        600: {
                            items: 2, // 2 items at a time for medium screens
                        },
                        1000: {
                            items: 4, // 3 items at a time for large screens
                        },
                    },
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $('.ps-categories__list').owlCarousel({
                    items: 4,
                    loop: true,
                    autoplay: true,
                    autoplayTimeout: 4000,
                    autoplaySpeed: 4000,
                    smartSpeed: 2000,
                    autoplayHoverPause: true,
                    nav: false,
                    dots: true,
                    responsive: {
                        0: {
                            items: 3,
                        },
                        576: {
                            items: 3,
                        },
                        768: {
                            items: 3,
                        },
                        1024: {
                            items: 4,
                        },
                    },
                });
            });
        </script>
        <script>
            $(document).ready(function() {
                $('.testigmonial-slider').owlCarousel({
                    animateOut: 'animate__slideOutDown', // Animate.css class (use "animate__" prefix)
                    animateIn: 'animate__flipInX', // Animate.css class (use "animate__" prefix)
                    items: 1, // Default number of items
                    margin: 30, // Remove margin between items
                    stagePadding: 30, // Padding around the stage
                    smartSpeed: 500, // Transition speed in ms
                    dots: true, // Show dots navigation
                    loop: true, // Infinite loop
                    autoplay: true, // Auto-scroll slides
                    autoplayTimeout: 3000, // Time between auto-scroll
                    autoplayHoverPause: true, // Pause on hover
                    mouseDrag: true, // Enable mouse scroll/drag
                    touchDrag: true, // Enable touch support
                    responsive: {
                        0: {
                            items: 1, // Display 1 item on small screens (up to 480px)
                        },
                        768: {
                            items: 1, // Display 2 items on medium screens (up to 768px)
                        },
                        1024: {
                            items: 1, // Display 3 items on larger screens (up to 1024px)
                        },
                        1200: {
                            items: 1, // Display 4 items on extra-large screens (above 1200px)
                        },
                    },
                });
            });
        </script>
        <script>
            const text = document.querySelector(".text-rounde");
            text.innerHTML = text.innerText
                .split("")
                .map((char, i) => {
                    const character = char === " " ? "&nbsp;" : char; // Replace spaces with non-breaking spaces
                    return `<span style="transform:rotate(${i * 10.3}deg)">${character}</span>`;
                })
                .join("");
        </script>
    <?php $__env->stopPush(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalceadbce536242cd820b2e0a9f88fc791)): ?>
<?php $attributes = $__attributesOriginalceadbce536242cd820b2e0a9f88fc791; ?>
<?php unset($__attributesOriginalceadbce536242cd820b2e0a9f88fc791); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalceadbce536242cd820b2e0a9f88fc791)): ?>
<?php $component = $__componentOriginalceadbce536242cd820b2e0a9f88fc791; ?>
<?php unset($__componentOriginalceadbce536242cd820b2e0a9f88fc791); ?>
<?php endif; ?>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/frontend/pages/home.blade.php ENDPATH**/ ?>