

<?php if (isset($component)) { $__componentOriginal016817b303def9c4a4470d2856743183 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal016817b303def9c4a4470d2856743183 = $attributes; } ?>
<?php $component = App\View\Components\AdminGuestLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin-guest-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AdminGuestLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute('404 Error')]); ?>
    <div class="d-flex flex-column flex-root">
        <div class="d-flex flex-column flex-column-fluid">
            <div class="d-flex flex-column flex-column-fluid text-center p-10 py-lg-15">
                <a href="<?php echo e(url('/')); ?>" class="mb-10 pt-lg-10">
                    <img alt="Logo" src="<?php echo e(!empty(optional($setting)->site_logo_black) ? asset('storage/' . optional($setting)->site_logo_black) : asset('frontend/img/logo.png')); ?>" class="h-40px mb-5" />
                </a>
                <div class="pt-lg-10 mb-10">
                    <h1 class="fw-bolder fs-2qx text-gray-800 mb-10">404</h1>
                    <div class="fw-bold fs-3 text-muted mb-15">Page Not Found!
                        <br /> Please Go back.
                    </div>
                    <div class="text-center">
                        <a href="<?php echo e(url('/')); ?>" class="btn btn-lg btn-primary fw-bolder">Go to homepage</a>
                    </div>
                </div>
                <div class="d-flex flex-row-auto bgi-no-repeat bgi-position-x-center bgi-size-contain bgi-position-y-bottom min-h-100px min-h-lg-350px"
                    style="background-image: url(<?php echo e(asset('admin/assets/media/illustrations/sketchy-1/17.png')); ?>)">
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal016817b303def9c4a4470d2856743183)): ?>
<?php $attributes = $__attributesOriginal016817b303def9c4a4470d2856743183; ?>
<?php unset($__attributesOriginal016817b303def9c4a4470d2856743183); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal016817b303def9c4a4470d2856743183)): ?>
<?php $component = $__componentOriginal016817b303def9c4a4470d2856743183; ?>
<?php unset($__componentOriginal016817b303def9c4a4470d2856743183); ?>
<?php endif; ?>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/errors/404.blade.php ENDPATH**/ ?>