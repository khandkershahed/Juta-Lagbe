<div class="row">
    <div class="col-xl-12">
        <h1>Advanced Setting</h1>
    </div>
    <div class="col-xl-12">
        <div class="row mt-10 px-5 align-items-center w-75 rounded-3">
            <div class="col-xl-4">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" value="1" name="user_verification"
                        id="user_verification" <?php echo e(old('user_verification', optional($setting)->user_verification) == '1' ? 'checked' : ''); ?> />
                    <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-check-label','for' => 'user_verification']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-check-label','for' => 'user_verification']); ?>
                        User Verification Checking
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                </div>
            </div>
            <div class="col-xl-8 mt-5">
                <div class="mb-10">
                    <?php if (isset($component)) { $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.label','data' => ['class' => 'form-label']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'form-label']); ?>Minimum Order Amount(Min: 0) <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $attributes = $__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__attributesOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe)): ?>
<?php $component = $__componentOriginal28130b6dbdccbe05d7a2606f76586bfe; ?>
<?php unset($__componentOriginal28130b6dbdccbe05d7a2606f76586bfe); ?>
<?php endif; ?>
                    <?php if (isset($component)) { $__componentOriginal6a4ff10c65103de020714e4a96286838 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6a4ff10c65103de020714e4a96286838 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.metronic.input','data' => ['type' => 'number','name' => 'minimum_order_amount','id' => 'minimum_order_amount','min' => '0','class' => 'form-control mb-2','placeholder' => 'User Minimum Order Amount','value' => old('minimum_order_amount', optional($setting)->minimum_order_amount)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('metronic.input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['type' => 'number','name' => 'minimum_order_amount','id' => 'minimum_order_amount','min' => '0','class' => 'form-control mb-2','placeholder' => 'User Minimum Order Amount','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old('minimum_order_amount', optional($setting)->minimum_order_amount))]); ?>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $attributes = $__attributesOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__attributesOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6a4ff10c65103de020714e4a96286838)): ?>
<?php $component = $__componentOriginal6a4ff10c65103de020714e4a96286838; ?>
<?php unset($__componentOriginal6a4ff10c65103de020714e4a96286838); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/admin/pages/setting/partials/advance.blade.php ENDPATH**/ ?>