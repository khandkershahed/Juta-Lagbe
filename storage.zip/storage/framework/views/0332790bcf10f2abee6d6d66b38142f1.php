<?php if($isLink ?? false): ?>
    <a href="<?php echo e($href ?? 'JavaScript:void(0)'); ?>" class="btn btn-<?php echo e($class ?? 'primary'); ?> font-weight-bold mr-2">
        <?php echo e($slot); ?>

    </a>
<?php else: ?>
    <button type="<?php echo e($type ?? 'button'); ?>" class="btn btn-<?php echo e($class ?? 'primary'); ?>" onclick="this.disabled = true; this.form.submit();">
        <?php echo e($slot); ?>

    </button>
<?php endif; ?>




<?php /**PATH H:\Projects\RajuVaiyaProjects\Juta-Lagbe\resources\views/components/metronic/button.blade.php ENDPATH**/ ?>